import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { 
  User, Crop, Disease, Product, Order, ForumPost, ForumReply, DiagnosisResult, ProductCategory, UserRole, CropStatus 
} from './src/types.js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
} else {
  console.log('WARNING: GEMINI_API_KEY not configured. AI Diagnostics will run in simulated mode.');
}

// Database JSON File Path
const DB_FILE = path.join(process.cwd(), 'db.json');

// Initial Seed Data
const initialDiseases: Disease[] = [
  {
    id: 'disease-1',
    name: 'Late Blight',
    description: 'A destructive fungal-like oomycete disease that attacks potatoes and tomatoes. It spreads rapidly in cool, wet environments, causing total crop failure if left untreated.',
    symptoms: 'Dark water-soaked spots on leaves that turn brown/black, white fuzzy mold growth on leaf undersides in humid conditions, and dark brown rotting areas on stems and tubers/fruit.',
    causes: 'Phytophthora infestans organism, promoted by high humidity and cool temperatures (15-20°C / 60-70°F).',
    prevention: 'Plant resistant crop varieties, ensure good air circulation, avoid overhead irrigation to keep foliage dry, rotate crops yearly, and apply copper-based fungicides preventatively.',
    affectedCrops: ['Potato', 'Tomato'],
    recommendedProductIds: ['prod-1', 'prod-3']
  },
  {
    id: 'disease-2',
    name: 'Powdery Mildew',
    description: 'A very common fungal disease affecting a wide range of plants. It slows plant growth and, in severe cases, causes leaves to wither and drop prematurely.',
    symptoms: 'Powdery white-to-gray spots or patches covering the surfaces of leaves, stems, or fruit. Infected leaves may curl, turn yellow, and dry out.',
    causes: 'Erysiphaceae fungi family, thriving in high humidity during warm days and cool nights, especially in shaded, dense plantings.',
    prevention: 'Space plants out to maximize sunlight and airflow, prune affected areas, water plants at the soil level rather than above, and apply sulfur dusting powder.',
    affectedCrops: ['Cucumber', 'Squash', 'Grape', 'Apple', 'Tomato'],
    recommendedProductIds: ['prod-2', 'prod-6']
  },
  {
    id: 'disease-3',
    name: 'Leaf Rust',
    description: 'A fungal disease that severely limits photosynthesis. Rust fungi are specialized pathogens that attack foliage, forming conspicuous colored spore pustules.',
    symptoms: 'Small, circular, orange-brown or reddish-brown powdery pustules on leaf surfaces. Seriously infected leaves turn yellow, wilt, and drop early.',
    causes: 'Puccinia species fungi, spread rapidly by wind-borne spores and moisture on foliage.',
    prevention: 'Sow rust-resistant seed cultivars, clear plant debris after harvest, apply preventive organic neem oil, and spray systemic fungicides if rust first appears.',
    affectedCrops: ['Wheat', 'Soybean', 'Beans', 'Maize'],
    recommendedProductIds: ['prod-4', 'prod-6']
  },
  {
    id: 'disease-4',
    name: 'Citrus Canker',
    description: 'A highly contagious bacterial disease affecting citrus crops. It causes lesions on leaves, stems, and fruit, leading to premature leaf and fruit drop and making fruit unmarketable.',
    symptoms: 'Raised, brown, cork-like lesions on leaves, twigs, and fruit, surrounded by a distinctive oily or yellow halo.',
    causes: 'Xanthomonas citri bacteria, spread by wind, splashing rain, contaminated tools, and leaf miners.',
    prevention: 'Disinfect farm equipment, install windbreaks, plant certified pathogen-free citrus stock, and apply copper sprays (Bordeaux mixture) during leaf expansion.',
    affectedCrops: ['Orange', 'Lemon', 'Lime', 'Grapefruit'],
    recommendedProductIds: ['prod-7', 'prod-1']
  }
];

const initialProducts: Product[] = [
  {
    id: 'prod-1',
    name: 'Organic Copper Fungicide',
    category: 'FUNGICIDE',
    price: 24.99,
    description: 'Concentrated liquid copper spray that controls and prevents Late Blight, Downy Mildew, and leaf spots. Safe for organic gardening.',
    diseaseId: 'disease-1',
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&q=80&w=400',
    cropType: 'Tomato, Potato'
  },
  {
    id: 'prod-2',
    name: 'Sulfur Dusting Powder',
    category: 'FUNGICIDE',
    price: 18.50,
    description: 'Specially formulated micro-fine elemental sulfur powder. Controls Powdery Mildew, Rust, and certain leaf mites on berries, cucumbers, and roses.',
    diseaseId: 'disease-2',
    image: 'https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?auto=format&fit=crop&q=80&w=400',
    cropType: 'Cucumber, Squash, Grapes'
  },
  {
    id: 'prod-3',
    name: 'Late Blight Resistant Potato Seeds',
    category: 'SEED',
    price: 14.00,
    description: 'Certified disease-free, high-yield seed potato tubers bred specifically to resist Phytophthora infestans (Late Blight) attacks.',
    diseaseId: 'disease-1',
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&q=80&w=400',
    cropType: 'Potato'
  },
  {
    id: 'prod-4',
    name: 'Resistant Wheat Cultivar Seeds (5kg)',
    category: 'SEED',
    price: 32.00,
    description: 'Premium quality wheat seeds bred for robust resistance against Stem and Leaf Rust pathogens. Outstanding grain quality.',
    diseaseId: 'disease-3',
    image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=400',
    cropType: 'Wheat'
  },
  {
    id: 'prod-5',
    name: 'Premium NPK Tomato Fertilizer (10-10-10)',
    category: 'FERTILIZER',
    price: 19.99,
    description: 'Formulated with balanced nutrients and essential calcium to strengthen cell walls, helping tomato and pepper crops resist blossom end rot and fungal pathogens.',
    image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&q=80&w=400',
    cropType: 'Tomato'
  },
  {
    id: 'prod-6',
    name: 'Cold-Pressed Organic Neem Oil Spray',
    category: 'PESTICIDE',
    price: 15.75,
    description: '100% natural pesticide and fungicide spray. Keeps away aphids, whiteflies, and spider mites while actively suppressing mildew and rust spores.',
    image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&q=80&w=400',
    cropType: 'All Crops'
  },
  {
    id: 'prod-7',
    name: 'Bordeaux Mixture Copper Sprayer',
    category: 'FUNGICIDE',
    price: 21.00,
    description: 'Classic combination of copper sulfate and hydrated lime. Highly reliable control for Citrus Canker, anthracnose, and peach leaf curl.',
    diseaseId: 'disease-4',
    image: 'https://images.unsplash.com/photo-1592417817098-8f3d6eb19675?auto=format&fit=crop&q=80&w=400',
    cropType: 'Citrus, Apple, Peach'
  },
  {
    id: 'prod-8',
    name: 'Premium Nitrogen Leaf Booster',
    category: 'FERTILIZER',
    price: 25.00,
    description: 'High-nitrogen liquid crop foliage food. Promotes rapid vegetative growth and leaf greening for young maize and legume fields.',
    image: 'https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?auto=format&fit=crop&q=80&w=400',
    cropType: 'Maize, Soybeans'
  }
];

interface DBState {
  users: (User & { password?: string })[];
  crops: Crop[];
  diseases: Disease[];
  products: Product[];
  orders: Order[];
  forum: ForumPost[];
}

// Ensure database file is initialized with seed data
function loadDB(): DBState {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    } catch (e) {
      console.error('Failed to parse database file. Recreating seeds.', e);
    }
  }

  const defaultDB: DBState = {
    users: [
      {
        id: 'farmer-1',
        name: 'Raj Patel',
        email: 'farmer@agrohealth.com',
        password: 'password',
        role: 'FARMER',
        phone: '+91 98765 43210',
        location: 'Anand District, Gujarat, India'
      },
      {
        id: 'expert-1',
        name: 'Dr. Sarah Miller',
        email: 'expert@agrohealth.com',
        password: 'password',
        role: 'EXPERT',
        phone: '+1 (555) 321-4567',
        location: 'Department of Agronomy, National Agro Institute'
      },
      {
        id: 'admin-1',
        name: 'AgroHealth Admin',
        email: 'admin@agrohealth.com',
        password: 'password',
        role: 'ADMIN'
      }
    ],
    crops: [
      {
        id: 'crop-1',
        farmerId: 'farmer-1',
        cropName: 'Potato',
        fieldSize: 4.5,
        season: 'Rabi / Winter',
        status: 'HEALTHY',
        plantedDate: '2026-05-10'
      },
      {
        id: 'crop-2',
        farmerId: 'farmer-1',
        cropName: 'Tomato',
        fieldSize: 2.0,
        season: 'Kharif / Summer',
        status: 'INFECTED',
        diseaseId: 'disease-1',
        plantedDate: '2026-06-01'
      }
    ],
    diseases: initialDiseases,
    products: initialProducts,
    orders: [
      {
        id: 'order-1',
        farmerId: 'farmer-1',
        items: [
          { productId: 'prod-1', name: 'Organic Copper Fungicide', price: 24.99, quantity: 2 },
          { productId: 'prod-5', name: 'Premium NPK Tomato Fertilizer (10-10-10)', price: 19.99, quantity: 1 }
        ],
        totalPrice: 69.97,
        status: 'DELIVERED',
        createdDate: '2026-06-15'
      }
    ],
    forum: [
      {
        id: 'post-1',
        authorId: 'farmer-1',
        authorName: 'Raj Patel',
        authorRole: 'FARMER',
        title: 'Dark patches appearing on Tomato leaves - advice needed!',
        content: 'Hi everyone, my Tomato field (Kharif season) has started showing these dark patches on the lower leaves. It has rained a lot over the past week and temperatures are quite mild. Is this Late Blight? What treatments do you recommend?',
        cropType: 'Tomato',
        diseaseId: 'disease-1',
        createdDate: '2026-06-25T10:30:00Z',
        replies: [
          {
            id: 'reply-1',
            authorId: 'expert-1',
            authorName: 'Dr. Sarah Miller',
            authorRole: 'EXPERT',
            content: 'Hello Raj! Based on the cool, wet conditions you described and the dark water-soaked patches, this does indeed sound like Late Blight (Phytophthora infestans). I highly recommend applying an Organic Copper Fungicide immediately and pruning any heavily infected branches. Make sure you avoid overhead watering during cool mornings.',
            createdDate: '2026-06-25T14:15:00Z'
          }
        ]
      }
    ]
  };

  saveDB(defaultDB);
  return defaultDB;
}

function saveDB(data: DBState) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// Initialize database
let db = loadDB();

// ==========================================
// API ENDPOINTS
// ==========================================

// Auth - Register
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role, phone, location } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: 'Name, email, password, and role are required.' });
  }

  const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: 'Email already registered.' });
  }

  const newUser: User & { password?: string } = {
    id: `user-${Date.now()}`,
    name,
    email: email.toLowerCase(),
    password,
    role: role as UserRole,
    phone,
    location
  };

  db.users.push(newUser);
  saveDB(db);

  // Exclude password in response
  const { password: _, ...userWithoutPassword } = newUser;
  res.status(201).json({ user: userWithoutPassword });
});

// Auth - Login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const { password: _, ...userWithoutPassword } = user;
  res.json({ user: userWithoutPassword });
});

// Crops API
app.get('/api/crops', (req, res) => {
  const { farmerId } = req.query;
  if (farmerId) {
    return res.json(db.crops.filter(c => c.farmerId === farmerId));
  }
  res.json(db.crops);
});

app.post('/api/crops', (req, res) => {
  const { farmerId, cropName, fieldSize, season, status, diseaseId } = req.body;

  if (!farmerId || !cropName || !fieldSize || !season) {
    return res.status(400).json({ error: 'Missing crop details.' });
  }

  const newCrop: Crop = {
    id: `crop-${Date.now()}`,
    farmerId,
    cropName,
    fieldSize: parseFloat(fieldSize),
    season,
    status: (status || 'HEALTHY') as CropStatus,
    diseaseId,
    plantedDate: new Date().toISOString().split('T')[0]
  };

  db.crops.push(newCrop);
  saveDB(db);
  res.status(201).json(newCrop);
});

app.put('/api/crops/:id', (req, res) => {
  const { id } = req.params;
  const { status, diseaseId } = req.body;

  const cropIndex = db.crops.findIndex(c => c.id === id);
  if (cropIndex === -1) {
    return res.status(404).json({ error: 'Crop not found.' });
  }

  db.crops[cropIndex] = {
    ...db.crops[cropIndex],
    status: status || db.crops[cropIndex].status,
    diseaseId: diseaseId !== undefined ? diseaseId : db.crops[cropIndex].diseaseId
  };

  saveDB(db);
  res.json(db.crops[cropIndex]);
});

app.delete('/api/crops/:id', (req, res) => {
  const { id } = req.params;
  const initialLen = db.crops.length;
  db.crops = db.crops.filter(c => c.id !== id);

  if (db.crops.length === initialLen) {
    return res.status(404).json({ error: 'Crop not found.' });
  }

  saveDB(db);
  res.json({ success: true, message: 'Crop removed successfully.' });
});

// Diseases API
app.get('/api/diseases', (req, res) => {
  res.json(db.diseases);
});

app.get('/api/diseases/:id', (req, res) => {
  const disease = db.diseases.find(d => d.id === req.params.id);
  if (!disease) return res.status(404).json({ error: 'Disease not found' });
  res.json(disease);
});

app.post('/api/diseases', (req, res) => {
  const { name, description, symptoms, causes, prevention, affectedCrops, recommendedProductIds } = req.body;
  if (!name || !description || !symptoms) {
    return res.status(400).json({ error: 'Name, description, and symptoms are required.' });
  }

  const newDisease: Disease = {
    id: `disease-${Date.now()}`,
    name,
    description,
    symptoms,
    causes: causes || '',
    prevention: prevention || '',
    affectedCrops: affectedCrops || [],
    recommendedProductIds: recommendedProductIds || []
  };

  db.diseases.push(newDisease);
  saveDB(db);
  res.status(201).json(newDisease);
});

// Products API
app.get('/api/products', (req, res) => {
  const { category, diseaseId } = req.query;
  let filtered = [...db.products];

  if (category) {
    filtered = filtered.filter(p => p.category === category);
  }
  if (diseaseId) {
    filtered = filtered.filter(p => p.diseaseId === diseaseId);
  }

  res.json(filtered);
});

app.post('/api/products', (req, res) => {
  const { name, category, price, description, diseaseId, image, cropType } = req.body;
  if (!name || !category || !price || !description) {
    return res.status(400).json({ error: 'Name, category, price, and description are required.' });
  }

  const newProduct: Product = {
    id: `prod-${Date.now()}`,
    name,
    category: category as ProductCategory,
    price: parseFloat(price),
    description,
    diseaseId,
    image: image || 'https://images.unsplash.com/photo-1592417817098-8f3d6eb19675?auto=format&fit=crop&q=80&w=400',
    cropType
  };

  db.products.push(newProduct);
  saveDB(db);
  res.status(201).json(newProduct);
});

// Orders API
app.get('/api/orders', (req, res) => {
  const { farmerId } = req.query;
  if (farmerId) {
    return res.json(db.orders.filter(o => o.farmerId === farmerId).sort((a,b) => b.createdDate.localeCompare(a.createdDate)));
  }
  res.json(db.orders);
});

app.post('/api/orders', (req, res) => {
  const { farmerId, items } = req.body;

  if (!farmerId || !items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Invalid order request. Items and farmerId required.' });
  }

  const totalPrice = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const newOrder: Order = {
    id: `order-${Date.now()}`,
    farmerId,
    items,
    totalPrice: parseFloat(totalPrice.toFixed(2)),
    status: 'PENDING',
    createdDate: new Date().toISOString().split('T')[0]
  };

  db.orders.push(newOrder);
  saveDB(db);
  res.status(201).json(newOrder);
});

app.put('/api/orders/:id', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const orderIndex = db.orders.findIndex(o => o.id === id);
  if (orderIndex === -1) {
    return res.status(404).json({ error: 'Order not found.' });
  }

  db.orders[orderIndex].status = status;
  saveDB(db);
  res.json(db.orders[orderIndex]);
});

// Forum / Expert Consultations API
app.get('/api/forum', (req, res) => {
  res.json(db.forum.sort((a,b) => b.createdDate.localeCompare(a.createdDate)));
});

app.post('/api/forum', (req, res) => {
  const { authorId, authorName, authorRole, title, content, cropType, diseaseId } = req.body;

  if (!authorId || !title || !content) {
    return res.status(400).json({ error: 'Author, title, and content are required.' });
  }

  const newPost: ForumPost = {
    id: `post-${Date.now()}`,
    authorId,
    authorName: authorName || 'Anonymous',
    authorRole: (authorRole || 'FARMER') as UserRole,
    title,
    content,
    cropType,
    diseaseId,
    replies: [],
    createdDate: new Date().toISOString()
  };

  db.forum.push(newPost);
  saveDB(db);
  res.status(201).json(newPost);
});

app.post('/api/forum/:id/reply', (req, res) => {
  const { id } = req.params;
  const { authorId, authorName, authorRole, content } = req.body;

  if (!authorId || !content) {
    return res.status(400).json({ error: 'Author ID and reply content are required.' });
  }

  const postIndex = db.forum.findIndex(p => p.id === id);
  if (postIndex === -1) {
    return res.status(404).json({ error: 'Post not found.' });
  }

  const newReply: ForumReply = {
    id: `reply-${Date.now()}`,
    authorId,
    authorName: authorName || 'Anonymous',
    authorRole: (authorRole || 'FARMER') as UserRole,
    content,
    createdDate: new Date().toISOString()
  };

  db.forum[postIndex].replies.push(newReply);
  saveDB(db);
  res.status(201).json(newReply);
});

// AI Disease Identifier API
app.post('/api/diagnosis', async (req, res) => {
  const { symptoms, cropType } = req.body;

  if (!symptoms) {
    return res.status(400).json({ error: 'Symptoms description is required.' });
  }

  // Create local catalogs search for pre-mapped diseases
  const matchedLocal = db.diseases.find(d => {
    // If the crop matches and we find a matching symptom keyword
    const cropMatches = !cropType || d.affectedCrops.some(c => c.toLowerCase() === cropType.toLowerCase());
    const symptomKeywords = d.symptoms.toLowerCase().split(/[ ,]+/);
    const symptomsInputLower = symptoms.toLowerCase();
    const hasSymptomMatch = symptomKeywords.some(word => word.length > 4 && symptomsInputLower.includes(word));
    return cropMatches && hasSymptomMatch;
  });

  // If Gemini API is available, we call it to perform smart analysis
  if (ai) {
    try {
      const prompt = `Analyze this agricultural crop condition description and identify the potential disease:
Crop Type: ${cropType || 'Unspecified'}
Farmer's Reported Symptoms: "${symptoms}"

Compare this description against known agricultural diseases (such as Late Blight, Powdery Mildew, Leaf Rust, Citrus Canker, etc.).
Produce a highly detailed diagnosis result in structured JSON format. Return ONLY a valid JSON object matching the schema below:

{
  "diseaseName": "Name of diagnosed crop disease",
  "confidence": 0.0 to 1.0 confidence score (number),
  "isMatch": true if it matches a known disease in general biology, false if unrecognized or healthy,
  "matchedDiseaseId": "Provide a likely match to our system database ids ('disease-1' for Late Blight, 'disease-2' for Powdery Mildew, 'disease-3' for Leaf Rust, 'disease-4' for Citrus Canker) ONLY if it strongly matches, otherwise null.",
  "description": "Short explanation of the disease and how it attacks.",
  "symptomsAnalysis": "A biological breakdown of the symptoms described by the farmer, detailing what is happening.",
  "solutions": [
    "Practical step-by-step agricultural remediation technique 1",
    "Practical step-by-step agricultural remediation technique 2"
  ],
  "recommendedProducts": [
    { "name": "General name of solution product (e.g. Copper Spray, Sulfur Powder, Neem Oil)", "type": "FUNGICIDE/PESTICIDE/FERTILIZER/SEED", "price": 20 }
  ]
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          systemInstruction: 'You are a professional senior agronomist, crop doctor, and plant pathologist helping farmers identify plant diseases and apply targeted chemical, organic, and cultivation solutions.'
        }
      });

      const text = response.text || '';
      const result: DiagnosisResult = JSON.parse(text.trim());
      
      // Attempt to link products from our catalog to recommended products
      let finalRecommended = [...result.recommendedProducts];
      if (result.matchedDiseaseId) {
        const matchingDbDisease = db.diseases.find(d => d.id === result.matchedDiseaseId);
        if (matchingDbDisease) {
          result.matchedDiseaseId = matchingDbDisease.id;
        }
      } else if (matchedLocal) {
        result.matchedDiseaseId = matchedLocal.id;
      }

      return res.json(result);
    } catch (error) {
      console.error('Gemini Diagnosis Error:', error);
      // Fallback to local heuristic diagnosis if Gemini fails
    }
  }

  // Local rule-based fallback / simulated diagnosis
  const localResponse: DiagnosisResult = matchedLocal ? {
    diseaseName: matchedLocal.name,
    confidence: 0.85,
    isMatch: true,
    matchedDiseaseId: matchedLocal.id,
    description: matchedLocal.description,
    symptomsAnalysis: `Reported symptoms matched database markers for ${matchedLocal.name}: ${matchedLocal.symptoms}`,
    solutions: matchedLocal.prevention.split(', '),
    recommendedProducts: db.products
      .filter(p => p.diseaseId === matchedLocal.id)
      .map(p => ({ name: p.name, type: p.category, price: p.price }))
  } : {
    diseaseName: 'Undetermined Crop Blight',
    confidence: 0.50,
    isMatch: false,
    description: 'We could not make a definite match with our standard disease records. This may be a nutrient deficiency, heat stress, or an uncommon pathogen.',
    symptomsAnalysis: 'The symptoms described do not clearly map to Late Blight, Powdery Mildew, Rust, or Citrus Canker.',
    solutions: [
      'Isolate the affected crops to prevent any potential spread.',
      'Check soil moisture and pH balance.',
      'Post a photo and symptom query in the AgroHealth Expert Q&A forum.'
    ],
    recommendedProducts: [
      { name: 'Organic Neem Oil Spray', type: 'PESTICIDE', price: 15.75 },
      { name: 'NPK Growth Booster 20-20-20', type: 'FERTILIZER', price: 25.00 }
    ]
  };

  res.json(localResponse);
});

// Serve frontend assets and start server
async function bootstrap() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AgroHealth full-stack server running on http://localhost:${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error('Failed to start AgroHealth server:', err);
});
