export type UserRole = 'FARMER' | 'EXPERT' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  location?: string;
}

export type CropStatus = 'HEALTHY' | 'INFECTED' | 'RECOVERING';

export interface Crop {
  id: string;
  farmerId: string;
  cropName: string;
  fieldSize: number; // in acres
  season: string;
  status: CropStatus;
  diseaseId?: string; // If infected
  plantedDate: string;
}

export interface Disease {
  id: string;
  name: string;
  description: string;
  symptoms: string;
  causes: string;
  prevention: string;
  affectedCrops: string[];
  recommendedProductIds: string[];
}

export type ProductCategory = 'FERTILIZER' | 'PESTICIDE' | 'SEED' | 'FUNGICIDE';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;
  description: string;
  diseaseId?: string; // Recommended for this disease, if any
  image?: string;
  cropType?: string;
}

export type OrderStatus = 'PENDING' | 'SHIPPED' | 'DELIVERED';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  farmerId: string;
  items: OrderItem[];
  totalPrice: number;
  status: OrderStatus;
  createdDate: string;
}

export interface ForumReply {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  content: string;
  createdDate: string;
}

export interface ForumPost {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  title: string;
  content: string;
  cropType?: string;
  diseaseId?: string;
  replies: ForumReply[];
  createdDate: string;
}

export interface DiagnosisResult {
  diseaseName: string;
  confidence: number; // e.g. 0.92
  isMatch: boolean; // whether matches a known disease or is new
  matchedDiseaseId?: string;
  description: string;
  symptomsAnalysis: string;
  solutions: string[];
  recommendedProducts: { name: string; type: string; price: number }[];
}
