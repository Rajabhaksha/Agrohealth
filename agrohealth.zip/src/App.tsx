import React, { useState, useEffect } from 'react';
import { 
  Sprout, ShoppingCart, User as UserIcon, ShieldCheck, Heart, AlertCircle, 
  MapPin, Phone, Mail, X, HelpCircle, Check, Loader2, CreditCard, Lock, Sparkles 
} from 'lucide-react';
import { User, Crop, Disease, Product, Order, ForumPost, UserRole, CropStatus } from './types';
import Navbar from './components/Navbar';
import FarmerDashboard from './components/FarmerDashboard';
import ExpertDashboard from './components/ExpertDashboard';
import AdminDashboard from './components/AdminDashboard';
import Marketplace from './components/Marketplace';
import ForumSection from './components/ForumSection';
import DiseaseCatalog from './components/DiseaseCatalog';

export default function App() {
  // Authentication & Roles
  const [currentUser, setCurrentUser] = useState<User | null>({
    id: 'farmer-1',
    name: 'Raj Patel',
    email: 'farmer@agrohealth.com',
    role: 'FARMER',
    phone: '+91 98765 43210',
    location: 'Anand District, Gujarat, India'
  });

  const [activeTab, setActiveTab] = useState<string>('farmer-dashboard');

  // Database States
  const [products, setProducts] = useState<Product[]>([]);
  const [diseases, setDiseases] = useState<Disease[]>([]);
  const [crops, setCrops] = useState<Crop[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [forumPosts, setForumPosts] = useState<ForumPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Shopping Cart State
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  // Modals States
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);

  // Login Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Register Form State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('FARMER');
  const [regPhone, setRegPhone] = useState('');
  const [regLocation, setRegLocation] = useState('');
  const [regError, setRegError] = useState('');

  // Sync API Data on Load or User Switch
  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [prodRes, disRes, forumRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/diseases'),
        fetch('/api/forum'),
      ]);

      const prods = await prodRes.json();
      const diss = await disRes.json();
      const posts = await forumRes.json();

      setProducts(prods);
      setDiseases(diss);
      setForumPosts(posts);

      if (currentUser) {
        // Fetch user-specific records
        const cropsUrl = currentUser.role === 'FARMER' ? `/api/crops?farmerId=${currentUser.id}` : '/api/crops';
        const ordersUrl = currentUser.role === 'FARMER' ? `/api/orders?farmerId=${currentUser.id}` : '/api/orders';

        const [cropRes, orderRes] = await Promise.all([
          fetch(cropsUrl),
          fetch(ordersUrl)
        ]);

        const crs = await cropRes.json();
        const ords = await orderRes.json();

        setCrops(crs);
        setOrders(ords);
      } else {
        setCrops([]);
        setOrders([]);
      }
    } catch (e) {
      console.error('Failed to synchronize data from AgroHealth servers', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [currentUser]);

  // Handle Quick Role Switching (Demo Convenience)
  const handleRoleQuickSwitch = (role: UserRole) => {
    if (role === 'FARMER') {
      const farmerObj: User = {
        id: 'farmer-1',
        name: 'Raj Patel',
        email: 'farmer@agrohealth.com',
        role: 'FARMER',
        phone: '+91 98765 43210',
        location: 'Anand District, Gujarat, India'
      };
      setCurrentUser(farmerObj);
      setActiveTab('farmer-dashboard');
    } else if (role === 'EXPERT') {
      const expertObj: User = {
        id: 'expert-1',
        name: 'Dr. Sarah Miller',
        email: 'expert@agrohealth.com',
        role: 'EXPERT',
        phone: '+1 (555) 321-4567',
        location: 'Department of Agronomy, National Agro Institute'
      };
      setCurrentUser(expertObj);
      setActiveTab('expert-dashboard');
    } else if (role === 'ADMIN') {
      const adminObj: User = {
        id: 'admin-1',
        name: 'AgroHealth Admin',
        email: 'admin@agrohealth.com',
        role: 'ADMIN'
      };
      setCurrentUser(adminObj);
      setActiveTab('admin-dashboard');
    }
    setCart([]); // Clear cart when roles switch
  };

  // Auth: Login submission
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Login failed.');
      }

      setCurrentUser(data.user);
      setIsLoginOpen(false);
      setLoginEmail('');
      setLoginPassword('');
      
      // Route accordingly
      if (data.user.role === 'FARMER') setActiveTab('farmer-dashboard');
      if (data.user.role === 'EXPERT') setActiveTab('expert-dashboard');
      if (data.user.role === 'ADMIN') setActiveTab('admin-dashboard');
    } catch (err: any) {
      setLoginError(err.message || 'Incorrect email or password combination.');
    }
  };

  // Auth: Register submission
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          email: regEmail,
          password: regPassword,
          role: regRole,
          phone: regPhone || undefined,
          location: regLocation || undefined
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Registration failed.');
      }

      setCurrentUser(data.user);
      setIsRegisterOpen(false);
      setRegName('');
      setRegEmail('');
      setRegPassword('');
      setRegPhone('');
      setRegLocation('');

      if (data.user.role === 'FARMER') setActiveTab('farmer-dashboard');
      if (data.user.role === 'EXPERT') setActiveTab('expert-dashboard');
    } catch (err: any) {
      setRegError(err.message || 'Failed to complete registration.');
    }
  };

  // Auth: Logout
  const handleLogout = () => {
    setCurrentUser(null);
    setCart([]);
    setActiveTab('marketplace');
  };

  // Cart Management
  const handleAddToCart = (product: Product, quantity: number) => {
    setCart((prevCart) => {
      const existing = prevCart.find((it) => it.product.id === product.id);
      if (existing) {
        return prevCart.map((it) => 
          it.product.id === product.id 
            ? { ...it, quantity: it.quantity + quantity } 
            : it
        );
      }
      return [...prevCart, { product, quantity }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQty = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((it) => it.product.id !== productId));
      return;
    }
    setCart((prev) => 
      prev.map((it) => (it.product.id === productId ? { ...it, quantity } : it))
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((it) => it.product.id !== productId));
  };

  // Checkout flow
  const handleCheckout = async () => {
    if (!currentUser) {
      setIsCartOpen(false);
      setIsLoginOpen(true);
      return;
    }

    setIsCheckingOut(true);
    try {
      const orderItems = cart.map((it) => ({
        productId: it.product.id,
        name: it.product.name,
        price: it.product.price,
        quantity: it.quantity
      }));

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmerId: currentUser.id,
          items: orderItems
        })
      });

      if (!res.ok) {
        throw new Error('Failed to post order transaction.');
      }

      setCart([]);
      setIsCartOpen(false);
      alert('Order placed successfully! Track your supply delivery status in your farm dashboard.');
      setActiveTab('farmer-dashboard');
      fetchData();
    } catch (err) {
      console.error(err);
      alert('Checkout transaction failed.');
    } finally {
      setIsCheckingOut(false);
    }
  };

  // Farmer: Crops Actions
  const handleAddCrop = async (cropData: Partial<Crop>) => {
    if (!currentUser) return;
    try {
      const res = await fetch('/api/crops', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...cropData, farmerId: currentUser.id })
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateCrop = async (id: string, status: CropStatus, diseaseId?: string) => {
    try {
      const res = await fetch(`/api/crops/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, diseaseId })
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteCrop = async (id: string) => {
    try {
      const res = await fetch(`/api/crops/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Forum Advisory actions
  const handleAddPost = async (postData: Partial<ForumPost>) => {
    if (!currentUser) return;
    try {
      const res = await fetch('/api/forum', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...postData,
          authorId: currentUser.id,
          authorName: currentUser.name,
          authorRole: currentUser.role
        })
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handlePostReply = async (postId: string, content: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/forum/${postId}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorId: currentUser.id,
          authorName: currentUser.name,
          authorRole: currentUser.role,
          content
        })
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Admin / Expert actions
  const handleAddProduct = async (productData: Partial<Product>) => {
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData)
      });
      if (res.ok) {
        fetchData();
      } else {
        const err = await res.json();
        throw new Error(err.error);
      }
    } catch (err) {
      throw err;
    }
  };

  const handleAddDisease = async (diseaseData: Partial<Disease>) => {
    try {
      const res = await fetch('/api/diseases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(diseaseData)
      });
      if (res.ok) {
        fetchData();
      } else {
        const err = await res.json();
        throw new Error(err.error);
      }
    } catch (err) {
      throw err;
    }
  };

  // Admin orders logistics updates
  const handleUpdateOrderStatus = async (orderId: string, status: Order['status']) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Cart total calculations
  const cartTotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans" id="app-root-container">
      
      {/* Central Navbar */}
      <Navbar
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onRoleSwitch={handleRoleQuickSwitch}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        isCartOpen={isCartOpen}
        setIsCartOpen={setIsCartOpen}
        onLogout={handleLogout}
        onOpenLogin={() => setIsLoginOpen(true)}
      />

      {/* Main Dynamic View Area */}
      <main className="flex-grow mx-auto max-w-7xl w-full px-4 sm:px-6 lg:px-8 py-8">
        {isLoading ? (
          <div className="flex h-96 items-center justify-center space-y-2 flex-col text-slate-400" id="global-data-loader">
            <Loader2 className="h-10 w-10 text-emerald-600 animate-spin" />
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Synchronizing AgroHealth agricultural data models...</p>
          </div>
        ) : (
          <div className="animate-fadeIn">
            {activeTab === 'farmer-dashboard' && currentUser?.role === 'FARMER' && (
              <FarmerDashboard
                crops={crops}
                diseases={diseases}
                products={products}
                orders={orders}
                onAddCrop={handleAddCrop}
                onUpdateCrop={handleUpdateCrop}
                onDeleteCrop={handleDeleteCrop}
                onAddToCart={handleAddToCart}
                onPlaceOrder={handleCheckout}
              />
            )}

            {activeTab === 'expert-dashboard' && currentUser?.role === 'EXPERT' && (
              <ExpertDashboard
                forumPosts={forumPosts}
                diseases={diseases}
                products={products}
                currentUser={currentUser}
                onPostReply={handlePostReply}
                onAddDisease={handleAddDisease}
              />
            )}

            {activeTab === 'admin-dashboard' && currentUser?.role === 'ADMIN' && (
              <AdminDashboard
                orders={orders}
                crops={crops}
                diseases={diseases}
                products={products}
                users={[
                  { id: 'farmer-1', name: 'Raj Patel', email: 'farmer@agrohealth.com', role: 'FARMER' },
                  { id: 'expert-1', name: 'Dr. Sarah Miller', email: 'expert@agrohealth.com', role: 'EXPERT' },
                ]}
                onUpdateOrderStatus={handleUpdateOrderStatus}
              />
            )}

            {activeTab === 'marketplace' && (
              <Marketplace
                products={products}
                diseases={diseases}
                currentUser={currentUser}
                onAddToCart={handleAddToCart}
                onAddProduct={handleAddProduct}
              />
            )}

            {activeTab === 'diseases' && (
              <DiseaseCatalog
                diseases={diseases}
                products={products}
                onAddToCart={handleAddToCart}
              />
            )}

            {activeTab === 'forum' && (
              <ForumSection
                posts={forumPosts}
                currentUser={currentUser}
                onAddPost={handleAddPost}
                onPostReply={handlePostReply}
                onOpenLogin={() => setIsLoginOpen(true)}
              />
            )}

            {activeTab === 'diagnosis' && currentUser?.role === 'FARMER' && (
              <FarmerDashboard
                crops={crops}
                diseases={diseases}
                products={products}
                orders={orders}
                onAddCrop={handleAddCrop}
                onUpdateCrop={handleUpdateCrop}
                onDeleteCrop={handleDeleteCrop}
                onAddToCart={handleAddToCart}
                onPlaceOrder={handleCheckout}
              />
            )}
          </div>
        )}
      </main>

      {/* Footer Area */}
      <footer className="border-t border-gray-200 bg-white py-8" id="platform-footer">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400 font-semibold">
          <div className="flex items-center space-x-2 text-emerald-700">
            <Sprout className="h-5 w-5" />
            <span className="text-gray-900 font-black">AgroHealth Advisory & Inputs Hub</span>
          </div>
          <p>© 2026 AgroHealth Platform. All Rights Reserved. Co-powered by Gemini Plant Pathologist.</p>
        </div>
      </footer>

      {/* ========================================== */}
      {/* SHOPPING CART DRAWER / SLIDE-IN */}
      {/* ========================================== */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden" aria-labelledby="slide-over-title" role="dialog" aria-modal="true" id="cart-drawer-overlay">
          <div className="absolute inset-0 overflow-hidden">
            {/* Backdrop close */}
            <div 
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-gray-500/75 transition-opacity"
            ></div>

            <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <div className="pointer-events-auto w-screen max-w-md">
                <div className="flex h-full flex-col bg-white shadow-2xl">
                  
                  {/* Cart Header */}
                  <div className="flex items-center justify-between border-b border-gray-100 p-5">
                    <h2 className="text-base font-bold text-gray-900 flex items-center space-x-1.5">
                      <ShoppingCart className="h-5 w-5 text-emerald-600" />
                      <span>My Solutions Shopping Cart</span>
                    </h2>
                    <button 
                      onClick={() => setIsCartOpen(false)}
                      className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-50 hover:text-gray-900 transition-all"
                      id="cart-drawer-close-btn"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>

                  {/* Cart Items list */}
                  <div className="flex-1 overflow-y-auto p-5">
                    {cart.length === 0 ? (
                      <div className="flex h-full flex-col items-center justify-center text-center space-y-2 text-gray-400">
                        <ShoppingCart className="h-10 w-10 text-gray-300" />
                        <p className="text-xs font-bold text-gray-700">Your shopping cart is empty</p>
                        <p className="text-[10px] text-gray-400 max-w-[200px]">Browse our pesticide catalog or run an AI crop diagnostic check to load targeted solutions.</p>
                      </div>
                    ) : (
                      <div className="space-y-4" id="cart-drawer-items-list">
                        {cart.map((item) => (
                          <div 
                            key={item.product.id} 
                            className="flex items-center justify-between border-b border-gray-50 pb-4 text-xs"
                            id={`cart-item-row-${item.product.id}`}
                          >
                            <div className="flex items-center space-x-3 flex-1 min-w-0">
                              <img 
                                src={item.product.image} 
                                alt={item.product.name}
                                referrerPolicy="no-referrer"
                                className="h-10 w-14 object-cover rounded-lg bg-gray-50"
                              />
                              <div className="min-w-0 flex-1">
                                <p className="font-extrabold text-gray-900 truncate">{item.product.name}</p>
                                <p className="text-emerald-700 font-bold mt-0.5">${item.product.price.toFixed(2)} each</p>
                              </div>
                            </div>

                            <div className="flex items-center space-x-3 ml-4">
                              <div className="flex items-center rounded-lg border border-gray-200">
                                <button
                                  onClick={() => handleUpdateCartQty(item.product.id, item.quantity - 1)}
                                  className="px-2 py-0.5 text-gray-400 hover:text-gray-900 font-semibold"
                                >
                                  -
                                </button>
                                <span className="px-2 font-bold text-gray-800">{item.quantity}</span>
                                <button
                                  onClick={() => handleUpdateCartQty(item.product.id, item.quantity + 1)}
                                  className="px-2 py-0.5 text-gray-400 hover:text-gray-900 font-semibold"
                                >
                                  +
                                </button>
                              </div>

                              <button
                                onClick={() => handleRemoveFromCart(item.product.id)}
                                className="text-red-500 hover:text-red-700 text-[10px] font-black"
                              >
                                Remove
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Cart Footer Total / Checkout */}
                  {cart.length > 0 && (
                    <div className="border-t border-gray-100 bg-gray-50 p-5 space-y-4">
                      <div className="flex justify-between text-xs font-semibold text-gray-600">
                        <span>Solutions Subtotal:</span>
                        <span className="text-sm font-black text-gray-950">${cartTotal.toFixed(2)}</span>
                      </div>

                      <button
                        onClick={handleCheckout}
                        disabled={isCheckingOut}
                        className="w-full flex items-center justify-center space-x-1.5 rounded-xl bg-emerald-600 py-3 font-bold text-white shadow-md shadow-emerald-100 hover:bg-emerald-700 transition-all disabled:opacity-50 text-sm"
                        id="cart-drawer-checkout-btn"
                      >
                        {isCheckingOut ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin" />
                            <span>Processing Payment...</span>
                          </>
                        ) : (
                          <>
                            <CreditCard className="h-4.5 w-4.5" />
                            <span>Proceed to Checkout</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}

                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* AUTH: LOGIN MODAL */}
      {/* ========================================== */}
      {isLoginOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4" id="login-modal-overlay">
          <div className="w-full max-w-sm rounded-2xl border border-gray-100 bg-white p-6 shadow-xl space-y-4 relative animate-scaleIn">
            <button 
              onClick={() => setIsLoginOpen(false)}
              className="absolute right-4 top-4 rounded-lg p-1 text-gray-400 hover:bg-gray-50 transition-all"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="text-center space-y-1">
              <div className="mx-auto rounded-xl bg-emerald-100 p-2.5 w-fit text-emerald-700">
                <Lock className="h-5.5 w-5.5" />
              </div>
              <h3 className="text-base font-black text-gray-950">Login to AgroHealth</h3>
              <p className="text-[10.5px] text-gray-400">Verify your farmer or advisor credentials</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="farmer@agrohealth.com"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-gray-900 outline-none focus:border-emerald-500"
                  id="login-email-input"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-gray-900 outline-none focus:border-emerald-500"
                  id="login-password-input"
                />
              </div>

              {loginError && (
                <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-100 text-[10.5px]">
                  <AlertCircle className="h-4 w-4 flex-shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full rounded-lg bg-emerald-600 py-2 font-bold text-white shadow-sm hover:bg-emerald-700 transition-all"
                id="login-submit-btn"
              >
                Sign In
              </button>
            </form>

            {/* Quick Demo Autofill Links (Reviewer Convenience) */}
            <div className="bg-gray-50 rounded-xl p-3 text-[10px] space-y-1.5 border border-gray-100">
              <p className="font-bold text-gray-400 uppercase tracking-wider">Reviewer Quick Fill:</p>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => {
                    setLoginEmail('farmer@agrohealth.com');
                    setLoginPassword('password');
                  }}
                  className="rounded bg-emerald-50 border border-emerald-100 px-2 py-0.5 text-emerald-800 font-bold"
                >
                  Farmer (Raj Patel)
                </button>
                <button
                  onClick={() => {
                    setLoginEmail('expert@agrohealth.com');
                    setLoginPassword('password');
                  }}
                  className="rounded bg-teal-50 border border-teal-100 px-2 py-0.5 text-teal-800 font-bold"
                >
                  Expert (Dr. Sarah)
                </button>
              </div>
            </div>

            <div className="text-center text-[10.5px] text-gray-500">
              Don't have an account?{' '}
              <button 
                onClick={() => {
                  setIsLoginOpen(false);
                  setIsRegisterOpen(true);
                }}
                className="font-bold text-emerald-600 hover:underline"
              >
                Register Now
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* AUTH: REGISTER MODAL */}
      {/* ========================================== */}
      {isRegisterOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4" id="register-modal-overlay">
          <div className="w-full max-w-sm rounded-2xl border border-gray-100 bg-white p-6 shadow-xl space-y-4 relative max-h-[90vh] overflow-y-auto animate-scaleIn">
            <button 
              onClick={() => setIsRegisterOpen(false)}
              className="absolute right-4 top-4 rounded-lg p-1 text-gray-400 hover:bg-gray-50 transition-all"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="text-center space-y-1">
              <div className="mx-auto rounded-xl bg-emerald-100 p-2.5 w-fit text-emerald-700">
                <UserIcon className="h-5.5 w-5.5" />
              </div>
              <h3 className="text-base font-black text-gray-950">Join AgroHealth</h3>
              <p className="text-[10.5px] text-gray-400">Register as a Farmer or Agronomist Advisor</p>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Anand Kumar"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-1.5 text-gray-900 outline-none focus:border-emerald-500"
                  id="register-name-input"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="e.g. anand@farmmail.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-1.5 text-gray-900 outline-none focus:border-emerald-500"
                  id="register-email-input"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Password *</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-1.5 text-gray-900 outline-none focus:border-emerald-500"
                  id="register-password-input"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Platform Account Role *</label>
                <select
                  value={regRole}
                  onChange={(e) => setRegRole(e.target.value as UserRole)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-1.5 text-gray-900 focus:border-emerald-500 focus:outline-none"
                  id="register-role-select"
                >
                  <option value="FARMER">Farmer (Track crops & buy inputs)</option>
                  <option value="EXPERT">Expert Agronomist (Provide consultations)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  placeholder="e.g. +91 99999 88888"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-1.5 text-gray-900 outline-none focus:border-emerald-500"
                  id="register-phone-input"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 mb-1">Location / Field Department</label>
                <input
                  type="text"
                  placeholder="e.g. Punjab, India"
                  value={regLocation}
                  onChange={(e) => setRegLocation(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-3 py-1.5 text-gray-900 outline-none focus:border-emerald-500"
                  id="register-location-input"
                />
              </div>

              {regError && (
                <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-100 text-[10.5px]">
                  <AlertCircle className="h-4 w-4 flex-shrink-0" />
                  <span>{regError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full rounded-lg bg-emerald-600 py-2 font-bold text-white shadow-sm hover:bg-emerald-700 transition-all"
                id="register-submit-btn"
              >
                Complete Registration
              </button>
            </form>

            <div className="text-center text-[10.5px] text-gray-500">
              Already have an account?{' '}
              <button 
                onClick={() => {
                  setIsRegisterOpen(false);
                  setIsLoginOpen(true);
                }}
                className="font-bold text-emerald-600 hover:underline"
              >
                Sign In
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
