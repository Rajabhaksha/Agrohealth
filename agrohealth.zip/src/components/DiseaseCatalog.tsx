import { Search, Database, Sprout, ShieldAlert, Check, ArrowRight, ShoppingBag } from 'lucide-react';
import { useState, useMemo } from 'react';
import { Disease, Product } from '../types';

interface DiseaseCatalogProps {
  diseases: Disease[];
  products: Product[];
  onAddToCart: (product: Product, quantity: number) => void;
  onSelectDiseaseTab?: (diseaseId: string) => void;
}

export default function DiseaseCatalog({
  diseases,
  products,
  onAddToCart,
  onSelectDiseaseTab,
}: DiseaseCatalogProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredDiseases = useMemo(() => {
    return diseases.filter((dis) => 
      dis.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dis.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dis.symptoms.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dis.affectedCrops.some(c => c.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [diseases, searchTerm]);

  const handleAddRemediesToCart = (diseaseId: string) => {
    const recommended = products.filter(p => p.diseaseId === diseaseId);
    if (recommended.length === 0) {
      // Add a general fertilizer or insecticide
      const fallback = products[0];
      if (fallback) onAddToCart(fallback, 1);
    } else {
      recommended.forEach(p => onAddToCart(p, 1));
    }
    alert(`Targeted remedies for this disease have been added to your shopping cart!`);
  };

  return (
    <div className="space-y-6" id="disease-catalog-section">
      
      {/* Upper banner info */}
      <div className="rounded-3xl border border-emerald-100 bg-emerald-50/50 p-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-emerald-950 flex items-center space-x-2">
            <Database className="h-5 w-5 text-emerald-600" />
            <span>Pathology & Crop Disease Encyclopedia</span>
          </h2>
          <p className="text-xs text-emerald-800 max-w-xl">
            Browse biological profiles of standard crop diseases, and study organic preventions and chemical treatment protocols.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative max-w-xs w-full">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search diseases or crops..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-gray-200 bg-white py-1.5 pl-9 pr-4 text-xs text-gray-950 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 transition-all shadow-sm"
            id="disease-search-input"
          />
        </div>
      </div>

      {/* Disease Cards grid */}
      {filteredDiseases.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed border-gray-100 rounded-3xl bg-white">
          <Database className="mx-auto h-12 w-12 text-gray-300" />
          <h3 className="mt-4 text-sm font-bold text-gray-900">No pathological profiles found</h3>
          <p className="mt-2 text-xs text-gray-500">Try adjusting your search keywords.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2" id="disease-catalog-grid-list">
          {filteredDiseases.map((dis) => {
            const remedies = products.filter(p => p.diseaseId === dis.id);

            return (
              <div 
                key={dis.id}
                className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                id={`catalog-disease-card-${dis.id}`}
              >
                <div>
                  {/* Name header */}
                  <div className="flex items-center justify-between border-b border-gray-50 pb-2 mb-3">
                    <h3 className="text-base font-black text-gray-950 flex items-center space-x-2">
                      <Sprout className="h-4.5 w-4.5 text-emerald-600" />
                      <span>{dis.name}</span>
                    </h3>
                    <span className="text-[10px] font-bold text-gray-400 bg-gray-50 border border-gray-100 px-2 py-0.5 rounded-lg">
                      {dis.affectedCrops.join(', ')}
                    </span>
                  </div>

                  <p className="text-xs text-gray-600 leading-relaxed">{dis.description}</p>

                  {/* Biological detail sections */}
                  <div className="mt-4 space-y-2.5 bg-gray-50/50 p-3.5 rounded-xl border border-gray-100">
                    <div className="text-xs">
                      <p className="font-bold text-gray-700 flex items-center space-x-1">
                        <ShieldAlert className="h-3.5 w-3.5 text-red-600" />
                        <span>Visual Symptoms:</span>
                      </p>
                      <p className="text-[11px] text-gray-600 mt-0.5 leading-relaxed font-medium">{dis.symptoms}</p>
                    </div>

                    {dis.causes && (
                      <div className="text-xs border-t border-gray-100 pt-2">
                        <p className="font-bold text-gray-700">Environmental Pathogen Causes:</p>
                        <p className="text-[11px] text-gray-600 mt-0.5 leading-relaxed font-medium">{dis.causes}</p>
                      </div>
                    )}

                    <div className="text-xs border-t border-gray-100 pt-2">
                      <p className="font-bold text-gray-700 flex items-center space-x-1">
                        <Check className="h-3.5 w-3.5 text-emerald-600" />
                        <span>Remediation & Preventative Care:</span>
                      </p>
                      <p className="text-[11px] text-gray-600 mt-0.5 leading-relaxed font-medium">{dis.prevention}</p>
                    </div>
                  </div>
                </div>

                {/* Bottom mapped solution button */}
                <div className="mt-5 pt-3 border-t border-gray-50 flex items-center justify-between">
                  <div className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-lg">
                    Mapped Store Treatments: {remedies.length} Products
                  </div>

                  <button
                    onClick={() => handleAddRemediesToCart(dis.id)}
                    className="inline-flex items-center space-x-1 text-xs font-black text-emerald-700 hover:text-emerald-950 transition-all"
                    id={`catalog-purchase-btn-${dis.id}`}
                  >
                    <ShoppingBag className="h-3.5 w-3.5 mr-1 text-emerald-600" />
                    <span>Get Remedies Package</span>
                    <ArrowRight className="h-3 w-3 ml-0.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
