import { useState, useMemo } from 'react';
import { 
  Activity, TrendingUp, ShoppingBag, ClipboardList, Package, UserCheck, 
  Settings, Check, Truck, Loader2, RefreshCw, BarChart2, Sprout, AlertTriangle 
} from 'lucide-react';
import { Order, Crop, Disease, Product, User } from '../types';

interface AdminDashboardProps {
  orders: Order[];
  crops: Crop[];
  diseases: Disease[];
  products: Product[];
  users: User[];
  onUpdateOrderStatus: (id: string, status: Order['status']) => Promise<void>;
}

export default function AdminDashboard({
  orders,
  crops,
  diseases,
  products,
  users,
  onUpdateOrderStatus,
}: AdminDashboardProps) {
  const [filterStatus, setFilterStatus] = useState<Order['status'] | 'ALL'>('ALL');
  const [isUpdatingId, setIsUpdatingId] = useState<string | null>(null);

  // Platform Analytics Calculations
  const stats = useMemo(() => {
    const totalUsersCount = users.length;
    const totalCropsCount = crops.length;
    const totalDiseasesCount = diseases.length;
    
    const grossSales = orders.reduce((sum, o) => sum + o.totalPrice, 0);
    const pendingOrdersCount = orders.filter(o => o.status === 'PENDING').length;

    // Crop health distribution
    const healthyCount = crops.filter(c => c.status === 'HEALTHY').length;
    const infectedCount = crops.filter(c => c.status === 'INFECTED').length;
    const recoveringCount = crops.filter(c => c.status === 'RECOVERING').length;

    return {
      totalUsersCount,
      totalCropsCount,
      totalDiseasesCount,
      grossSales,
      pendingOrdersCount,
      healthyCount,
      infectedCount,
      recoveringCount
    };
  }, [orders, crops, diseases, users]);

  const filteredOrders = useMemo(() => {
    if (filterStatus === 'ALL') return orders;
    return orders.filter(o => o.status === filterStatus);
  }, [orders, filterStatus]);

  const handleUpdateStatus = async (orderId: string, nextStatus: Order['status']) => {
    setIsUpdatingId(orderId);
    try {
      await onUpdateOrderStatus(orderId, nextStatus);
    } catch (err) {
      console.error(err);
    } finally {
      setIsUpdatingId(null);
    }
  };

  return (
    <div className="space-y-8" id="admin-dashboard-section">
      
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold text-gray-900">Platform Management Hub</h2>
        <p className="text-xs text-gray-500">Monitor crop epidemics, track gross revenue, and handle certified supply shipments.</p>
      </div>

      {/* Grid Stats Cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4" id="admin-stats-counters">
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Gross Revenue</p>
          <p className="text-lg font-black text-gray-900">${stats.grossSales.toFixed(2)}</p>
          <div className="flex items-center space-x-1 text-[10px] font-bold text-emerald-600 mt-1">
            <TrendingUp className="h-3 w-3" />
            <span>Store Sales Live</span>
          </div>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Tracked Crop Fields</p>
          <p className="text-lg font-black text-gray-900">{stats.totalCropsCount}</p>
          <p className="text-[10px] text-gray-500 font-medium">Logged by regional farmers</p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Pathology Database</p>
          <p className="text-lg font-black text-gray-900">{stats.totalDiseasesCount}</p>
          <p className="text-[10px] text-gray-500 font-medium">Active diagnostic templates</p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-1">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Pending Orders</p>
          <p className="text-lg font-black text-yellow-600">{stats.pendingOrdersCount}</p>
          <p className="text-[10px] text-gray-500 font-medium">Awaiting packaging</p>
        </div>
      </div>

      {/* Analytics Visualization and Crop Health overview */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        
        {/* Crop health distribution chart */}
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-gray-900 flex items-center space-x-2">
            <BarChart2 className="h-4.5 w-4.5 text-emerald-600" />
            <span>Outbreak Analytics & Crop Health Distribution</span>
          </h3>

          <div className="space-y-3.5 pt-2">
            {/* Healthy bar */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-gray-600 mb-1">
                <span className="flex items-center space-x-1">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-500"></span>
                  <span>Healthy Cultivations</span>
                </span>
                <span>{stats.healthyCount} fields ({stats.totalCropsCount ? Math.round((stats.healthyCount / stats.totalCropsCount) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-2 transition-all duration-500"
                  style={{ width: `${stats.totalCropsCount ? (stats.healthyCount / stats.totalCropsCount) * 100 : 0}%` }}
                ></div>
              </div>
            </div>

            {/* Recovering bar */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-gray-600 mb-1">
                <span className="flex items-center space-x-1">
                  <span className="h-2.5 w-2.5 rounded-full bg-teal-500"></span>
                  <span>Recovering (Remediation Injected)</span>
                </span>
                <span>{stats.recoveringCount} fields ({stats.totalCropsCount ? Math.round((stats.recoveringCount / stats.totalCropsCount) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-teal-500 h-2 transition-all duration-500"
                  style={{ width: `${stats.totalCropsCount ? (stats.recoveringCount / stats.totalCropsCount) * 100 : 0}%` }}
                ></div>
              </div>
            </div>

            {/* Infected bar */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-gray-600 mb-1">
                <span className="flex items-center space-x-1">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500 animate-pulse"></span>
                  <span className="font-bold text-red-700">Active Pathogen Epidemics</span>
                </span>
                <span>{stats.infectedCount} fields ({stats.totalCropsCount ? Math.round((stats.infectedCount / stats.totalCropsCount) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-red-500 h-2 transition-all duration-500"
                  style={{ width: `${stats.totalCropsCount ? (stats.infectedCount / stats.totalCropsCount) * 100 : 0}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Informative advice panel */}
        <div className="rounded-2xl border border-emerald-100 bg-emerald-50/30 p-6 flex flex-col justify-between">
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-emerald-950 flex items-center space-x-2">
              <Sprout className="h-4.5 w-4.5 text-emerald-600" />
              <span>Epidemic Mitigation Directives</span>
            </h3>
            <p className="text-xs text-emerald-800 leading-relaxed">
              Platform telemetry highlights that <span className="font-bold">{stats.infectedCount} fields</span> are suffering from active infections. Ensure chemical copper sprays and elemental sulfur fungicides are well stocked in the Marketplace to prevent further spores expansion.
            </p>
          </div>

          <div className="border-t border-emerald-100/65 pt-4 mt-4 text-xs font-bold text-emerald-900 flex justify-between items-center">
            <span>Overall Pathogen Threat Level:</span>
            <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-black ${
              stats.infectedCount > 3 ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
            }`}>
              {stats.infectedCount > 3 ? 'HIGH OUTBREAK ALERT' : 'MODERATE EPIDEMIOLOGY'}
            </span>
          </div>
        </div>

      </div>

      {/* Orders Fulfilment Dashboard */}
      <div className="space-y-4" id="admin-orders-fulfillment">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h3 className="text-sm font-bold text-gray-900 flex items-center space-x-2">
            <ClipboardList className="h-4.5 w-4.5 text-emerald-600" />
            <span>Platform Order Fulfillment Tracking</span>
          </h3>

          {/* Filters tabs */}
          <div className="flex space-x-1.5 rounded-lg bg-gray-100 p-1 text-xs font-bold text-gray-500">
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`rounded-md px-2.5 py-1 ${filterStatus === 'ALL' ? 'bg-white text-gray-900 shadow-sm' : 'hover:text-gray-900'}`}
            >
              All ({orders.length})
            </button>
            <button
              onClick={() => setFilterStatus('PENDING')}
              className={`rounded-md px-2.5 py-1 ${filterStatus === 'PENDING' ? 'bg-white text-yellow-800 shadow-sm' : 'hover:text-gray-900'}`}
            >
              Pending ({orders.filter(o => o.status === 'PENDING').length})
            </button>
            <button
              onClick={() => setFilterStatus('SHIPPED')}
              className={`rounded-md px-2.5 py-1 ${filterStatus === 'SHIPPED' ? 'bg-white text-blue-800 shadow-sm' : 'hover:text-gray-900'}`}
            >
              Shipped ({orders.filter(o => o.status === 'SHIPPED').length})
            </button>
            <button
              onClick={() => setFilterStatus('DELIVERED')}
              className={`rounded-md px-2.5 py-1 ${filterStatus === 'DELIVERED' ? 'bg-white text-emerald-800 shadow-sm' : 'hover:text-gray-900'}`}
            >
              Delivered ({orders.filter(o => o.status === 'DELIVERED').length})
            </button>
          </div>
        </div>

        {/* Fulfillment list */}
        {filteredOrders.length === 0 ? (
          <div className="text-center py-12 border border-gray-100 rounded-3xl bg-white">
            <Package className="mx-auto h-12 w-12 text-gray-300" />
            <h3 className="mt-4 text-sm font-bold text-gray-900">No orders match filter</h3>
            <p className="mt-2 text-xs text-gray-500">Adjust the filter status to find previous orders.</p>
          </div>
        ) : (
          <div className="space-y-4" id="admin-orders-fulfillment-list">
            {filteredOrders.map((order) => (
              <div 
                key={order.id}
                className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-4 hover:border-emerald-100 transition-colors"
                id={`fulfillment-order-card-${order.id}`}
              >
                {/* Header row */}
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-gray-50 pb-3">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-gray-900">Order ID: {order.id}</span>
                      <span className="text-[10px] text-gray-400">Purchased on {order.createdDate}</span>
                    </div>
                    <p className="text-[10px] text-emerald-700 font-semibold mt-0.5">Farmer ID: {order.farmerId}</p>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                      order.status === 'DELIVERED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : order.status === 'SHIPPED'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                </div>

                {/* items */}
                <div className="space-y-2 text-xs">
                  {order.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between items-center">
                      <p className="text-gray-700 font-medium">
                        {it.name} <span className="text-gray-400 font-semibold ml-1">x{it.quantity}</span>
                      </p>
                      <p className="font-bold text-gray-900">${(it.price * it.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                </div>

                {/* total & action panel */}
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between pt-3 border-t border-gray-50">
                  <div className="text-xs font-semibold text-gray-500">
                    Gross Total: <span className="font-black text-emerald-950 text-sm">${order.totalPrice.toFixed(2)}</span>
                  </div>

                  <div className="flex space-x-2">
                    {order.status === 'PENDING' && (
                      <button
                        onClick={() => handleUpdateStatus(order.id, 'SHIPPED')}
                        disabled={isUpdatingId === order.id}
                        className="rounded-lg bg-blue-600 px-3.5 py-1.5 text-[10px] font-black text-white hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-1"
                      >
                        <Truck className="h-3.5 w-3.5" />
                        <span>Ship Solutions Bundle</span>
                      </button>
                    )}

                    {order.status === 'SHIPPED' && (
                      <button
                        onClick={() => handleUpdateStatus(order.id, 'DELIVERED')}
                        disabled={isUpdatingId === order.id}
                        className="rounded-lg bg-emerald-600 px-3.5 py-1.5 text-[10px] font-black text-white hover:bg-emerald-700 disabled:opacity-50 flex items-center space-x-1"
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>Confirm Safe Delivery</span>
                      </button>
                    )}

                    {order.status === 'DELIVERED' && (
                      <span className="inline-flex items-center space-x-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg">
                        <Check className="h-3 w-3" />
                        <span>Sought Delivery Completed</span>
                      </span>
                    )}
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>

    </div>
  );
}
