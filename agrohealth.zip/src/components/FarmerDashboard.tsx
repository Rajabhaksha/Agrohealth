import React, { useState } from 'react';
import { 
  Sprout, Plus, Search, HelpCircle, Activity, ShieldAlert, Sparkles, AlertCircle, 
  Check, Trash2, Calendar, ClipboardList, ShoppingCart, Loader2, ArrowRight, BookOpen 
} from 'lucide-react';
import { Crop, CropStatus, Disease, Product, Order, DiagnosisResult } from '../types';

interface FarmerDashboardProps {
  crops: Crop[];
  diseases: Disease[];
  products: Product[];
  orders: Order[];
  onAddCrop: (cropData: Partial<Crop>) => Promise<void>;
  onUpdateCrop: (id: string, status: CropStatus, diseaseId?: string) => Promise<void>;
  onDeleteCrop: (id: string) => Promise<void>;
  onAddToCart: (product: Product, quantity: number) => void;
  onPlaceOrder: (items: any[]) => Promise<void>;
}

export default function FarmerDashboard({
  crops,
  diseases,
  products,
  orders,
  onAddCrop,
  onUpdateCrop,
  onDeleteCrop,
  onAddToCart,
  onPlaceOrder,
}: FarmerDashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<'my-farm' | 'ai-diagnosis' | 'orders'>('my-farm');

  // Add Crop Form State
  const [isAddingCrop, setIsAddingCrop] = useState(false);
  const [newCropName, setNewCropName] = useState('');
  const [newFieldSize, setNewFieldSize] = useState('');
  const [newSeason, setNewSeason] = useState('Kharif / Summer');
  const [newStatus, setNewStatus] = useState<CropStatus>('HEALTHY');
  const [newDiseaseId, setNewDiseaseId] = useState('');

  // AI Diagnostic State
  const [diagnosticSymptoms, setDiagnosticSymptoms] = useState('');
  const [diagnosticCrop, setDiagnosticCrop] = useState('Tomato');
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState<DiagnosisResult | null>(null);
  const [diagnosisError, setDiagnosisError] = useState('');

  // Add Crop Handler
  const handleAddCropSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCropName || !newFieldSize) return;

    try {
      await onAddCrop({
        cropName: newCropName,
        fieldSize: parseFloat(newFieldSize),
        season: newSeason,
        status: newStatus,
        diseaseId: newStatus === 'INFECTED' ? newDiseaseId : undefined
      });

      // Clear Form
      setNewCropName('');
      setNewFieldSize('');
      setNewSeason('Kharif / Summer');
      setNewStatus('HEALTHY');
      setNewDiseaseId('');
      setIsAddingCrop(false);
    } catch (err) {
      console.error(err);
    }
  };

  // Run AI Diagnostic Handler
  const handleRunDiagnosis = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!diagnosticSymptoms) return;

    setIsDiagnosing(true);
    setDiagnosisError('');
    setDiagnosisResult(null);

    try {
      const response = await fetch('/api/diagnosis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symptoms: diagnosticSymptoms,
          cropType: diagnosticCrop
        })
      });

      if (!response.ok) {
        throw new Error('Failed to reach AI Diagnostics service.');
      }

      const result = await response.json();
      setDiagnosisResult(result);
    } catch (err: any) {
      setDiagnosisError(err.message || 'Error occurred while contacting the Agronomist AI.');
    } finally {
      setIsDiagnosing(false);
    }
  };

  // Quick purchase treatment pack handler
  const handlePurchaseRemedies = (recommendedProds: any[]) => {
    let addedCount = 0;
    recommendedProds.forEach((rec) => {
      // Find matching product in catalog
      const actualProduct = products.find(p => 
        p.name.toLowerCase().includes(rec.name.toLowerCase()) ||
        rec.name.toLowerCase().includes(p.name.toLowerCase())
      );
      if (actualProduct) {
        onAddToCart(actualProduct, 1);
        addedCount++;
      } else {
        // Fallback: Add general neem oil or first fungicide
        const backupFungicide = products.find(p => p.category === 'FUNGICIDE');
        if (backupFungicide) {
          onAddToCart(backupFungicide, 1);
          addedCount++;
        }
      }
    });

    if (addedCount > 0) {
      alert(`${addedCount} treatment products loaded successfully into your shopping cart!`);
    } else {
      // Add general copper fungicide
      const backup = products[0];
      if (backup) {
        onAddToCart(backup, 1);
        alert('Added general Treatment Spray package to your cart.');
      }
    }
  };

  // Apply diagnosis directly to active crops
  const handleApplyDiagnosisToFarm = async (diseaseName: string, matchedDiseaseId?: string) => {
    // Check if farmer already has this crop tracked, update it
    const cropToUpdate = crops.find(c => c.cropName.toLowerCase() === diagnosticCrop.toLowerCase());
    if (cropToUpdate) {
      await onUpdateCrop(cropToUpdate.id, 'INFECTED', matchedDiseaseId || 'disease-1');
      alert(`Updated your tracked ${cropToUpdate.cropName} crop status to INFECTED with ${diseaseName}.`);
    } else {
      // Register new crop
      await onAddCrop({
        cropName: diagnosticCrop,
        fieldSize: 1.0,
        season: 'Current Season',
        status: 'INFECTED',
        diseaseId: matchedDiseaseId || 'disease-1'
      });
      alert(`Registered new ${diagnosticCrop} crop in your farm tracker under INFECTED - ${diseaseName}.`);
    }
  };

  return (
    <div className="space-y-6" id="farmer-dashboard-section">
      
      {/* Sub Tabs Toggle Bar */}
      <div className="flex border-b border-gray-200 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveSubTab('my-farm')}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-semibold transition-all ${
            activeSubTab === 'my-farm'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
          }`}
          id="farmer-subtab-myfarm"
        >
          <Sprout className="h-4 w-4" />
          <span>My Farm Fields</span>
        </button>
        <button
          onClick={() => setActiveSubTab('ai-diagnosis')}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-semibold transition-all ${
            activeSubTab === 'ai-diagnosis'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
          }`}
          id="farmer-subtab-diagnosis"
        >
          <Sparkles className="h-4 w-4 text-emerald-600" />
          <span className="flex items-center space-x-1">
            <span>AI Plant Doctor</span>
            <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[9px] font-black uppercase text-emerald-800 tracking-wider">
              Gemini
            </span>
          </span>
        </button>
        <button
          onClick={() => setActiveSubTab('orders')}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-semibold transition-all ${
            activeSubTab === 'orders'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
          }`}
          id="farmer-subtab-orders"
        >
          <ClipboardList className="h-4 w-4" />
          <span>Order History</span>
        </button>
      </div>

      {/* SUB-TAB: MY FARM FIELDS */}
      {activeSubTab === 'my-farm' && (
        <div className="space-y-6" id="farmer-subtab-myfarm-view">
          
          {/* Header Action */}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Crop Health Tracker</h2>
              <p className="text-xs text-gray-500">Log what crops you are growing, review pathogen threats, and update recovery rates.</p>
            </div>
            <button
              onClick={() => setIsAddingCrop(!isAddingCrop)}
              className="flex items-center justify-center space-x-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-all"
              id="farmer-add-crop-btn"
            >
              <Plus className="h-4 w-4" />
              <span>Register Crop Field</span>
            </button>
          </div>

          {/* Add Crop Drawer */}
          {isAddingCrop && (
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50/40 p-5 shadow-inner" id="add-crop-form-container">
              <h3 className="text-sm font-bold text-emerald-950 mb-3 flex items-center space-x-2">
                <Sprout className="h-4 w-4 text-emerald-600" />
                <span>Register a Cultivation Field</span>
              </h3>
              <form onSubmit={handleAddCropSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Crop Variety *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Russet Potato, Plum Tomato"
                    value={newCropName}
                    onChange={(e) => setNewCropName(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Field Size (Acres) *</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    required
                    placeholder="e.g. 5.5"
                    value={newFieldSize}
                    onChange={(e) => setNewFieldSize(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Crop Season</label>
                  <input
                    type="text"
                    placeholder="e.g. Winter / Rabi"
                    value={newSeason}
                    onChange={(e) => setNewSeason(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Initial Health Status</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as CropStatus)}
                    className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="HEALTHY">Healthy / Standard</option>
                    <option value="INFECTED">Infected / Showing Symptoms</option>
                    <option value="RECOVERING">Recovering / Under Treatment</option>
                  </select>
                </div>

                {newStatus === 'INFECTED' && (
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Pathogen / Disease</label>
                    <select
                      value={newDiseaseId}
                      onChange={(e) => setNewDiseaseId(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    >
                      <option value="">Unknown Disease</option>
                      {diseases.map((d) => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="sm:col-span-2 md:col-span-3 flex justify-end space-x-2 pt-2 border-t border-emerald-100/65">
                  <button
                    type="button"
                    onClick={() => setIsAddingCrop(false)}
                    className="rounded-lg px-4 py-1.5 text-xs font-semibold text-gray-500 hover:bg-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="rounded-lg bg-emerald-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-all shadow-sm"
                  >
                    Save Field Log
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Tracked Fields Card Grid */}
          {crops.length === 0 ? (
            <div className="text-center py-16 border-2 border-dashed border-gray-100 rounded-3xl" id="farmer-farm-empty-state">
              <Sprout className="mx-auto h-12 w-12 text-gray-300 animate-bounce" />
              <h3 className="mt-4 text-sm font-bold text-gray-900">No active crop fields tracked</h3>
              <p className="mt-2 text-xs text-gray-500 max-w-xs mx-auto">
                Log which crops you have currently planted to track pathogen outbreaks or access customized expert inputs.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3" id="crops-card-grid-list">
              {crops.map((crop) => {
                const affectedDisease = diseases.find(d => d.id === crop.diseaseId);

                return (
                  <div 
                    key={crop.id}
                    className={`rounded-2xl border bg-white p-5 shadow-sm transition-all hover:shadow-md flex flex-col justify-between ${
                      crop.status === 'INFECTED' 
                        ? 'border-red-100 shadow-red-50/20' 
                        : crop.status === 'RECOVERING' 
                        ? 'border-teal-100 shadow-teal-50/20' 
                        : 'border-gray-100'
                    }`}
                    id={`crop-field-card-${crop.id}`}
                  >
                    <div>
                      {/* Top status bar */}
                      <div className="flex items-center justify-between">
                        <span className="flex items-center space-x-1 text-gray-400 text-xs font-semibold">
                          <Calendar className="h-3.5 w-3.5" />
                          <span>Planted: {crop.plantedDate}</span>
                        </span>

                        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold leading-5 ${
                          crop.status === 'HEALTHY'
                            ? 'bg-emerald-100 text-emerald-800'
                            : crop.status === 'INFECTED'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-teal-100 text-teal-800'
                        }`}>
                          {crop.status}
                        </span>
                      </div>

                      {/* Title & Stats */}
                      <h4 className="mt-3 text-base font-extrabold text-gray-900">{crop.cropName}</h4>
                      <p className="mt-1 text-xs text-gray-500 font-medium">
                        Field Size: <span className="font-bold text-gray-700">{crop.fieldSize} Acres</span> • Season: <span className="font-bold text-gray-700">{crop.season}</span>
                      </p>

                      {/* Outbreak details if infected */}
                      {crop.status === 'INFECTED' && (
                        <div className="mt-4 rounded-xl bg-red-50 p-3.5 border border-red-100">
                          <div className="flex space-x-2 text-xs">
                            <ShieldAlert className="h-4.5 w-4.5 text-red-600 flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="font-bold text-red-950">Active Pathogen: {affectedDisease?.name || 'Unidentified Outbreak'}</p>
                              <p className="text-[10px] text-red-700 mt-1 leading-relaxed">{affectedDisease?.description || 'Recommend running AI Diagnosis check.'}</p>
                            </div>
                          </div>
                          
                          {/* Recommended product links */}
                          {affectedDisease && (
                            <div className="mt-3 pt-3 border-t border-red-100 flex items-center justify-between">
                              <span className="text-[10px] font-bold text-red-800 uppercase tracking-wide">Target treatments available</span>
                              <button
                                onClick={() => {
                                  const matchingProds = products.filter(p => p.diseaseId === affectedDisease.id);
                                  handlePurchaseRemedies(matchingProds);
                                }}
                                className="inline-flex items-center space-x-1 text-[10px] font-black text-red-700 hover:text-red-900"
                              >
                                <span>Get remedies</span>
                                <ArrowRight className="h-3 w-3" />
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Recovering message */}
                      {crop.status === 'RECOVERING' && (
                        <div className="mt-4 rounded-xl bg-teal-50 p-3.5 border border-teal-100">
                          <div className="flex space-x-2 text-xs">
                            <Check className="h-4.5 w-4.5 text-teal-600 flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="font-bold text-teal-950">Recovery Stage</p>
                              <p className="text-[10px] text-teal-700 mt-1 leading-relaxed">Remediation inputs have been applied. Keep monitoring humidity levels weekly.</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Bottom field controls */}
                    <div className="mt-5 flex items-center justify-between border-t border-gray-50 pt-3">
                      <div className="flex items-center space-x-2">
                        {crop.status !== 'HEALTHY' && (
                          <button
                            onClick={() => onUpdateCrop(crop.id, 'HEALTHY', undefined)}
                            className="rounded-lg bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700 hover:bg-emerald-100"
                          >
                            Mark Healthy
                          </button>
                        )}
                        {crop.status === 'HEALTHY' && (
                          <button
                            onClick={() => onUpdateCrop(crop.id, 'INFECTED', 'disease-1')}
                            className="rounded-lg bg-red-50 px-2.5 py-1 text-[10px] font-bold text-red-700 hover:bg-red-100"
                          >
                            Mark Infected
                          </button>
                        )}
                      </div>

                      <button
                        onClick={() => onDeleteCrop(crop.id)}
                        className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-50 hover:text-red-600 transition-colors"
                        title="Delete log"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* SUB-TAB: AI PLANT DOCTOR */}
      {activeSubTab === 'ai-diagnosis' && (
        <div className="space-y-6" id="farmer-subtab-diagnosis-view">
          
          <div className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-6">
            <h2 className="text-xl font-bold text-emerald-950 flex items-center space-x-2">
              <Sparkles className="h-5.5 w-5.5 text-emerald-600" />
              <span>Gemini AI Plant Pathologist</span>
            </h2>
            <p className="mt-2 text-xs text-emerald-800 leading-relaxed max-w-3xl">
              Type in the physical anomalies, spots, molds, or growth anomalies your crops are expressing. Our Gemini-driven plant diagnostic model will instantly evaluate the symptoms, search pathogen biological profiles, and prescribe remedies.
            </p>

            <form onSubmit={handleRunDiagnosis} className="mt-5 space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="sm:col-span-1">
                  <label className="block text-xs font-bold text-emerald-950 mb-1">Crop Under Examination</label>
                  <select
                    value={diagnosticCrop}
                    onChange={(e) => setDiagnosticCrop(e.target.value)}
                    className="w-full rounded-xl border border-emerald-200 bg-white px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    id="ai-diagnosis-crop-select"
                  >
                    <option value="Tomato">Tomato</option>
                    <option value="Potato">Potato</option>
                    <option value="Cucumber">Cucumber</option>
                    <option value="Squash">Squash</option>
                    <option value="Wheat">Wheat</option>
                    <option value="Beans">Beans</option>
                    <option value="Citrus">Citrus (Lemon/Orange)</option>
                    <option value="Maize">Maize / Corn</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-emerald-950 mb-1">Enter Crop Symptoms *</label>
                  <input
                    type="text"
                    required
                    placeholder="Describe color, spots, leaf curls, fuzzy mold, or stem rot details..."
                    value={diagnosticSymptoms}
                    onChange={(e) => setDiagnosticSymptoms(e.target.value)}
                    className="w-full rounded-xl border border-emerald-200 bg-white px-3.5 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    id="ai-diagnosis-symptoms-input"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isDiagnosing}
                  className="flex items-center space-x-2 rounded-xl bg-emerald-600 px-6 py-2.5 text-sm font-bold text-white hover:bg-emerald-700 disabled:bg-emerald-400 transition-all shadow-md shadow-emerald-100"
                  id="ai-diagnosis-submit-btn"
                >
                  {isDiagnosing ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Analyzing Pathogen Profile...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      <span>Diagnose Crop Health</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* AI Loader status messaging */}
          {isDiagnosing && (
            <div className="rounded-2xl border border-gray-100 bg-white p-8 text-center space-y-3 shadow-sm" id="ai-diagnosis-loading-state">
              <Loader2 className="mx-auto h-8 w-8 text-emerald-600 animate-spin" />
              <p className="text-sm font-bold text-gray-800">Reviewing plant tissue anomalies...</p>
              <p className="text-xs text-gray-400 max-w-sm mx-auto">Evaluating symptoms against late blight spores, mold classifications, and chemical deficiencies.</p>
            </div>
          )}

          {/* Diagnosis results render panel */}
          {diagnosisResult && (
            <div className="rounded-2xl border border-emerald-100 bg-white p-6 shadow-md space-y-6 animate-fadeIn" id="ai-diagnosis-results-card">
              
              {/* Header result row */}
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-gray-100 pb-4">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100">Diagnosis Output</span>
                    <span className="text-xs font-medium text-gray-400">Confidence: {(diagnosisResult.confidence * 100).toFixed(0)}%</span>
                  </div>
                  <h3 className="text-xl font-black text-gray-900 mt-1">{diagnosisResult.diseaseName}</h3>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => handleApplyDiagnosisToFarm(diagnosisResult.diseaseName, diagnosisResult.matchedDiseaseId)}
                    className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 hover:bg-emerald-100 transition-all"
                    id="ai-diagnosis-apply-farm-btn"
                  >
                    Apply to Farm Fields
                  </button>
                </div>
              </div>

              {/* Grid content columns */}
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  {/* description card */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Pathology Overview</h4>
                    <p className="text-xs text-gray-700 leading-relaxed">{diagnosisResult.description}</p>
                  </div>

                  {/* biological leaf breakdown */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Symptom Assessment</h4>
                    <p className="text-xs text-gray-700 leading-relaxed bg-gray-50 p-3 rounded-xl border border-gray-100">{diagnosisResult.symptomsAnalysis}</p>
                  </div>
                </div>

                {/* remedies & chemical actions */}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Prescribed Agronomic Techniques</h4>
                    <ul className="space-y-2">
                      {diagnosisResult.solutions.map((sol, index) => (
                        <li key={index} className="flex space-x-2 text-xs text-gray-700 leading-relaxed">
                          <Check className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                          <span>{sol}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* recommended products shop integration */}
              <div className="rounded-xl bg-emerald-900 p-5 text-white flex flex-col gap-4 md:flex-row md:items-center md:justify-between shadow-sm">
                <div className="space-y-1">
                  <h4 className="text-sm font-bold flex items-center space-x-1">
                    <ShoppingCart className="h-4.5 w-4.5 text-emerald-300" />
                    <span>Targeted Solutions Package</span>
                  </h4>
                  <p className="text-[10.5px] text-emerald-100 max-w-xl">
                    Our agronomist database mapped {diagnosisResult.recommendedProducts.length} certified treatments corresponding to your crops' diagnosis. Buy the prescribed chemical/organic bundle below.
                  </p>
                </div>

                <button
                  onClick={() => handlePurchaseRemedies(diagnosisResult.recommendedProducts)}
                  className="rounded-xl bg-white px-5 py-2 text-xs font-bold text-emerald-950 shadow-sm hover:bg-emerald-50 transition-all flex items-center justify-center space-x-1.5"
                  id="ai-diagnosis-purchase-package-btn"
                >
                  <span>Add Recommended Products to Cart</span>
                  <ArrowRight className="h-3.5 w-3.5 text-emerald-700" />
                </button>
              </div>

            </div>
          )}

        </div>
      )}

      {/* SUB-TAB: ORDER HISTORY */}
      {activeSubTab === 'orders' && (
        <div className="space-y-6" id="farmer-subtab-orders-view">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Purchase Order History</h2>
            <p className="text-xs text-gray-500">Track shipping, packaging, and logistical processing of seeds and treatment inputs.</p>
          </div>

          {orders.length === 0 ? (
            <div className="text-center py-16 border-2 border-dashed border-gray-100 rounded-3xl" id="farmer-orders-empty-state">
              <ClipboardList className="mx-auto h-12 w-12 text-gray-300" />
              <h3 className="mt-4 text-sm font-bold text-gray-900">No previous orders logged</h3>
              <p className="mt-2 text-xs text-gray-500 max-w-xs mx-auto">
                Items you purchase from our certified Marketplace will appear here with dynamic tracking statuses.
              </p>
            </div>
          ) : (
            <div className="space-y-4" id="orders-history-list">
              {orders.map((order) => (
                <div 
                  key={order.id}
                  className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-4"
                  id={`order-history-card-${order.id}`}
                >
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-gray-50 pb-3">
                    <div>
                      <p className="text-xs text-gray-400 font-semibold">Order ID: {order.id}</p>
                      <p className="text-xs text-gray-500 mt-0.5">Purchased on {order.createdDate}</p>
                    </div>

                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider ${
                      order.status === 'DELIVERED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : order.status === 'SHIPPED'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {order.status}
                    </span>
                  </div>

                  {/* items catalog list */}
                  <div className="space-y-2">
                    {order.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs">
                        <div className="text-gray-700">
                          <span className="font-bold text-gray-900">{it.name}</span>
                          <span className="text-gray-400 ml-1.5">Qty: {it.quantity}</span>
                        </div>
                        <span className="font-semibold text-gray-900">${(it.price * it.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center border-t border-gray-50 pt-3 text-sm">
                    <span className="font-bold text-gray-500">Total Price</span>
                    <span className="font-black text-emerald-950">${order.totalPrice.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
