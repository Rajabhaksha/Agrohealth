import React, { useState, useMemo } from 'react';
import { Search, Filter, ShoppingBag, Plus, Tag, Check, HelpCircle, Package, ArrowRight, ShieldAlert, X } from 'lucide-react';
import { Product, ProductCategory, Disease, User } from '../types';

interface MarketplaceProps {
  products: Product[];
  diseases: Disease[];
  currentUser: User | null;
  onAddToCart: (product: Product, quantity: number) => void;
  onAddProduct: (productData: Partial<Product>) => Promise<void>;
}

export default function Marketplace({
  products,
  diseases,
  currentUser,
  onAddToCart,
  onAddProduct,
}: MarketplaceProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'ALL'>('ALL');
  const [selectedDiseaseId, setSelectedDiseaseId] = useState<string | 'ALL'>('ALL');
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  
  // State for Add Product Form (Admins / Experts)
  const [isAdding, setIsAdding] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<ProductCategory>('FERTILIZER');
  const [newProdPrice, setNewProdPrice] = useState('');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdDiseaseId, setNewProdDiseaseId] = useState('');
  const [newProdCropType, setNewProdCropType] = useState('');
  const [newProdImage, setNewProdImage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const categories: (ProductCategory | 'ALL')[] = ['ALL', 'FERTILIZER', 'PESTICIDE', 'SEED', 'FUNGICIDE'];

  const filteredProducts = useMemo(() => {
    return products.filter((prod) => {
      const matchesSearch = 
        prod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prod.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (prod.cropType && prod.cropType.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesCategory = selectedCategory === 'ALL' || prod.category === selectedCategory;
      const matchesDisease = selectedDiseaseId === 'ALL' || prod.diseaseId === selectedDiseaseId;

      return matchesSearch && matchesCategory && matchesDisease;
    });
  }, [products, searchTerm, selectedCategory, selectedDiseaseId]);

  const handleQtyChange = (productId: string, val: number) => {
    setQuantities(prev => ({
      ...prev,
      [productId]: Math.max(1, val)
    }));
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName || !newProdPrice || !newProdDesc) {
      setSubmitError('Product name, price, and description are required.');
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
      await onAddProduct({
        name: newProdName,
        category: newProdCategory,
        price: parseFloat(newProdPrice),
        description: newProdDesc,
        diseaseId: newProdDiseaseId || undefined,
        cropType: newProdCropType || undefined,
        image: newProdImage || undefined
      });

      // Clear Form
      setNewProdName('');
      setNewProdPrice('');
      setNewProdDesc('');
      setNewProdDiseaseId('');
      setNewProdCropType('');
      setNewProdImage('');
      setIsAdding(false);
    } catch (err: any) {
      setSubmitError(err.message || 'Failed to add product. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8" id="marketplace-section">
      
      {/* Upper Banner Section */}
      <div className="relative overflow-hidden rounded-3xl bg-emerald-900 px-6 py-12 text-white sm:px-12 sm:py-16 shadow-xl">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center rounded-full bg-emerald-800 px-3 py-1 text-xs font-semibold text-emerald-200">
            Certified Storefront
          </span>
          <h1 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
            Agricultural Input Marketplace
          </h1>
          <p className="mt-4 text-emerald-100 leading-relaxed text-sm sm:text-base">
            Browse state-tested, disease-preventative seeds, bio-fertilizers, targeted fungicides, and natural pest solutions curated by agronomists to protect your yields.
          </p>
        </div>
        <div className="absolute right-0 top-0 hidden lg:block opacity-20 transform translate-x-12 -translate-y-12">
          <ShoppingBag className="h-96 w-96 text-emerald-300" />
        </div>
      </div>

      {/* Filter and Search Bar controls */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search products, crops (e.g., Potato) or chemicals..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-gray-200 bg-white py-2.5 pl-10 pr-4 text-sm text-gray-900 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 transition-all shadow-sm"
            id="marketplace-search-input"
          />
        </div>

        {/* Quick Filter Selectors */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Disease Map Filter */}
          <div className="flex items-center space-x-1 rounded-xl border border-gray-200 bg-white px-3 py-1.5 shadow-sm text-xs">
            <Filter className="h-3.5 w-3.5 text-gray-400" />
            <span className="font-semibold text-gray-500 mr-1">Target Disease:</span>
            <select
              value={selectedDiseaseId}
              onChange={(e) => setSelectedDiseaseId(e.target.value)}
              className="bg-transparent font-medium text-emerald-700 focus:outline-none"
              id="marketplace-disease-select"
            >
              <option value="ALL">All Diseases</option>
              {diseases.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>

          {/* Expert / Admin Add Product trigger */}
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'EXPERT') && (
            <button
              onClick={() => setIsAdding(!isAdding)}
              className="flex items-center space-x-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-all shadow-sm"
              id="marketplace-add-product-toggle"
            >
              <Plus className="h-4 w-4" />
              <span>Add Store Product</span>
            </button>
          )}
        </div>
      </div>

      {/* Adding Product Form Drawer/Panel */}
      {isAdding && (
        <div className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-6 shadow-inner animate-fadeIn" id="marketplace-add-form-container">
          <div className="flex items-center justify-between border-b border-emerald-100 pb-3 mb-4">
            <h3 className="text-base font-bold text-emerald-950 flex items-center space-x-2">
              <Package className="h-5 w-5 text-emerald-600" />
              <span>Add New Agricultural Product to Inventory</span>
            </h3>
            <button 
              onClick={() => setIsAdding(false)}
              className="rounded-lg p-1.5 text-gray-400 hover:bg-white hover:text-gray-900 transition-all"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <form onSubmit={handleAddSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Product Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Copper Spray Solution"
                value={newProdName}
                onChange={(e) => setNewProdName(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-900 focus:border-emerald-500 focus:outline-none"
                id="add-prod-name"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Category *</label>
              <select
                value={newProdCategory}
                onChange={(e) => setNewProdCategory(e.target.value as ProductCategory)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-emerald-950 focus:border-emerald-500 focus:outline-none"
                id="add-prod-category"
              >
                <option value="FERTILIZER">Fertilizer</option>
                <option value="PESTICIDE">Pesticide</option>
                <option value="SEED">Seeds / Seedlings</option>
                <option value="FUNGICIDE">Fungicide / Treatment</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Price ($ USD) *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                placeholder="24.99"
                value={newProdPrice}
                onChange={(e) => setNewProdPrice(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-900 focus:border-emerald-500 focus:outline-none"
                id="add-prod-price"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Compatible Crop Types</label>
              <input
                type="text"
                placeholder="e.g. Potato, Tomato"
                value={newProdCropType}
                onChange={(e) => setNewProdCropType(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-900 focus:border-emerald-500 focus:outline-none"
                id="add-prod-crop"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Target Plant Disease Mapping</label>
              <select
                value={newProdDiseaseId}
                onChange={(e) => setNewProdDiseaseId(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-900 focus:border-emerald-500 focus:outline-none"
                id="add-prod-disease"
              >
                <option value="">None (General Use Input)</option>
                {diseases.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Product Image URL (Optional)</label>
              <input
                type="url"
                placeholder="https://images.unsplash.com/..."
                value={newProdImage}
                onChange={(e) => setNewProdImage(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-900 focus:border-emerald-500 focus:outline-none"
                id="add-prod-image"
              />
            </div>

            <div className="sm:col-span-2 md:col-span-3">
              <label className="block text-xs font-bold text-gray-700 mb-1">Product Description *</label>
              <textarea
                required
                rows={2}
                placeholder="Detailed usage specifications, biological compositions, application guidelines..."
                value={newProdDesc}
                onChange={(e) => setNewProdDesc(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-900 focus:border-emerald-500 focus:outline-none"
                id="add-prod-desc"
              />
            </div>

            {submitError && (
              <div className="sm:col-span-2 md:col-span-3 flex items-center space-x-2 text-sm text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-100">
                <ShieldAlert className="h-4 w-4" />
                <span>{submitError}</span>
              </div>
            )}

            <div className="sm:col-span-2 md:col-span-3 flex justify-end space-x-2 pt-2 border-t border-emerald-100">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="rounded-lg px-4 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="rounded-lg bg-emerald-600 px-5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-all disabled:opacity-50"
                id="add-prod-submit-btn"
              >
                {isSubmitting ? 'Adding Product...' : 'Add to Inventory'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Category Tabs Selector */}
      <div className="flex border-b border-gray-200 overflow-x-auto pb-px" id="marketplace-category-tabs">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`whitespace-nowrap border-b-2 px-6 py-3 text-sm font-semibold transition-all focus:outline-none ${
              selectedCategory === cat
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
            }`}
            id={`category-tab-${cat}`}
          >
            {cat === 'ALL' ? 'All Products' : cat.charAt(0) + cat.slice(1).toLowerCase() + 's'}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-16 border-2 border-dashed border-gray-100 rounded-3xl" id="marketplace-empty-state">
          <ShoppingBag className="mx-auto h-12 w-12 text-gray-300" />
          <h3 className="mt-4 text-base font-bold text-gray-900">No matching products found</h3>
          <p className="mt-2 text-sm text-gray-500 max-w-sm mx-auto">
            Try adjusting your category filter, clearing your search input, or selecting a different target disease.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4" id="products-grid-list">
          {filteredProducts.map((prod) => {
            const qty = quantities[prod.id] || 1;
            const correspondingDisease = diseases.find((d) => d.id === prod.diseaseId);

            return (
              <div 
                key={prod.id} 
                className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-gray-100 bg-white transition-all duration-300 hover:shadow-lg hover:border-emerald-100"
                id={`product-card-${prod.id}`}
              >
                {/* Product Image Panel */}
                <div className="relative aspect-video w-full overflow-hidden bg-gray-50">
                  <img
                    src={prod.image || 'https://images.unsplash.com/photo-1592417817098-8f3d6eb19675?auto=format&fit=crop&q=80&w=400'}
                    alt={prod.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  
                  {/* Category Pill Tag */}
                  <span className="absolute left-3 top-3 inline-flex items-center rounded-lg bg-black/60 px-2 py-0.5 text-[10px] font-semibold text-white backdrop-blur-sm uppercase">
                    {prod.category.toLowerCase()}
                  </span>

                  {/* Disease Targeted Tag */}
                  {correspondingDisease && (
                    <span className="absolute right-3 top-3 inline-flex items-center rounded-lg bg-red-600/90 px-2 py-0.5 text-[10px] font-bold text-white shadow-sm">
                      Target: {correspondingDisease.name}
                    </span>
                  )}
                </div>

                {/* Info and action blocks */}
                <div className="flex flex-1 flex-col p-4">
                  {/* Crop Type compatibility indicator */}
                  {prod.cropType && (
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 mb-1">
                      Fits: {prod.cropType}
                    </span>
                  )}

                  <h4 className="text-sm font-bold text-gray-900 group-hover:text-emerald-700 transition-colors line-clamp-1">
                    {prod.name}
                  </h4>
                  
                  <p className="mt-1.5 text-xs text-gray-500 line-clamp-2 leading-relaxed flex-1">
                    {prod.description}
                  </p>

                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-base font-bold text-emerald-950">${prod.price.toFixed(2)}</span>
                  </div>

                  {/* Actions Block */}
                  {(!currentUser || currentUser.role === 'FARMER') ? (
                    <div className="mt-4 flex items-center space-x-2 pt-3 border-t border-gray-50">
                      {/* Quantity Select */}
                      <div className="flex items-center rounded-lg border border-gray-200">
                        <button
                          onClick={() => handleQtyChange(prod.id, qty - 1)}
                          className="px-2.5 py-1 text-sm text-gray-500 hover:bg-gray-100 hover:text-gray-900"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-bold text-gray-800">{qty}</span>
                        <button
                          onClick={() => handleQtyChange(prod.id, qty + 1)}
                          className="px-2.5 py-1 text-sm text-gray-500 hover:bg-gray-100 hover:text-gray-900"
                        >
                          +
                        </button>
                      </div>

                      {/* Add Button */}
                      <button
                        onClick={() => onAddToCart(prod, qty)}
                        className="flex-1 flex items-center justify-center space-x-1 rounded-lg bg-emerald-600 py-1.5 px-3 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 hover:shadow transition-all"
                        id={`add-to-cart-btn-${prod.id}`}
                      >
                        <ShoppingBag className="h-3.5 w-3.5" />
                        <span>Add</span>
                      </button>
                    </div>
                  ) : (
                    <div className="mt-4 pt-3 border-t border-gray-50 text-center">
                      <span className="inline-flex items-center rounded-lg bg-gray-50 border border-gray-100 px-3 py-1 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                        Store Inventory Mode
                      </span>
                    </div>
                  )}

                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
