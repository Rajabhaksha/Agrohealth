import React, { useState } from 'react';
import { 
  ShieldCheck, HelpCircle, MessageSquare, Database, Plus, Check, MapPin, 
  BookOpen, Sprout, AlertCircle, FileText, ClipboardList, Trash2 
} from 'lucide-react';
import { ForumPost, ForumReply, Disease, User, Product } from '../types';

interface ExpertDashboardProps {
  forumPosts: ForumPost[];
  diseases: Disease[];
  products: Product[];
  currentUser: User | null;
  onPostReply: (postId: string, replyContent: string) => Promise<void>;
  onAddDisease: (diseaseData: Partial<Disease>) => Promise<void>;
}

export default function ExpertDashboard({
  forumPosts,
  diseases,
  products,
  currentUser,
  onPostReply,
  onAddDisease,
}: ExpertDashboardProps) {
  const [expertSubTab, setExpertSubTab] = useState<'consultations' | 'disease-db'>('consultations');

  // Reply States
  const [activeReplyPostId, setActiveReplyPostId] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);

  // Add Disease State
  const [isAddingDisease, setIsAddingDisease] = useState(false);
  const [disName, setDisName] = useState('');
  const [disDesc, setDisDesc] = useState('');
  const [disSymptoms, setDisSymptoms] = useState('');
  const [disCauses, setDisCauses] = useState('');
  const [disPrevention, setDisPrevention] = useState('');
  const [disCrops, setDisCrops] = useState('');
  const [disRecProducts, setDisRecProducts] = useState<string[]>([]);
  const [isSubmittingDisease, setIsSubmittingDisease] = useState(false);
  const [diseaseError, setDiseaseError] = useState('');

  // Submit Reply Handler
  const handleReplySubmit = async (postId: string) => {
    if (!replyContent.trim()) return;
    setIsSubmittingReply(true);

    try {
      await onPostReply(postId, replyContent);
      setReplyContent('');
      setActiveReplyPostId(null);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmittingReply(false);
    }
  };

  // Submit Disease Handler
  const handleDiseaseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!disName || !disDesc || !disSymptoms) {
      setDiseaseError('Disease name, description, and symptoms are required.');
      return;
    }

    setIsSubmittingDisease(true);
    setDiseaseError('');

    try {
      await onAddDisease({
        name: disName,
        description: disDesc,
        symptoms: disSymptoms,
        causes: disCauses,
        prevention: disPrevention,
        affectedCrops: disCrops.split(',').map(c => c.trim()).filter(Boolean),
        recommendedProductIds: disRecProducts
      });

      // Reset
      setDisName('');
      setDisDesc('');
      setDisSymptoms('');
      setDisCauses('');
      setDisPrevention('');
      setDisCrops('');
      setDisRecProducts([]);
      setIsAddingDisease(false);
    } catch (err: any) {
      setDiseaseError(err.message || 'Failed to add disease profile.');
    } finally {
      setIsSubmittingDisease(false);
    }
  };

  const handleProductToggle = (prodId: string) => {
    setDisRecProducts(prev => 
      prev.includes(prodId) ? prev.filter(id => id !== prodId) : [...prev, prodId]
    );
  };

  return (
    <div className="space-y-6" id="expert-dashboard-section">
      
      {/* Tab Selectors */}
      <div className="flex border-b border-gray-200 overflow-x-auto pb-px">
        <button
          onClick={() => setExpertSubTab('consultations')}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-semibold transition-all ${
            expertSubTab === 'consultations'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
          }`}
          id="expert-tab-consultations"
        >
          <MessageSquare className="h-4 w-4" />
          <span>Farmer Consultations ({forumPosts.filter(p => p.replies.length === 0).length} Unanswered)</span>
        </button>
        <button
          onClick={() => setExpertSubTab('disease-db')}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-semibold transition-all ${
            expertSubTab === 'disease-db'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
          }`}
          id="expert-tab-diseasedb"
        >
          <Database className="h-4 w-4" />
          <span>Pathology Catalog Control</span>
        </button>
      </div>

      {/* VIEW: CONSULTATIONS */}
      {expertSubTab === 'consultations' && (
        <div className="space-y-6" id="expert-view-consultations">
          
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Crop Health Advisory Forum</h2>
              <p className="text-xs text-gray-500">Provide verified agronomical guidance to farmer symptom queries and pest outbreak reports.</p>
            </div>
          </div>

          <div className="space-y-6" id="consultation-questions-list">
            {forumPosts.length === 0 ? (
              <div className="text-center py-12 border border-gray-100 rounded-3xl bg-white shadow-sm">
                <HelpCircle className="mx-auto h-12 w-12 text-gray-300 animate-pulse" />
                <h3 className="mt-4 text-sm font-bold text-gray-900">No advisory consultations logged</h3>
                <p className="mt-2 text-xs text-gray-500 max-w-xs mx-auto">
                  When farmers submit symptom queries or forum discussions, they will populate here for agronomist evaluation.
                </p>
              </div>
            ) : (
              forumPosts.map((post) => (
                <div 
                  key={post.id}
                  className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-4"
                  id={`expert-question-card-${post.id}`}
                >
                  {/* Question Header */}
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100">
                          Crop: {post.cropType || 'General'}
                        </span>
                        <span className="text-[10px] text-gray-400 font-semibold">Posted by {post.authorName}</span>
                      </div>
                      <h4 className="text-base font-extrabold text-gray-950 mt-1.5">{post.title}</h4>
                    </div>

                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                      post.replies.length > 0
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-100'
                        : 'bg-red-50 text-red-800 border border-red-100 animate-pulse'
                    }`}>
                      {post.replies.length > 0 ? 'Answered' : 'Action Required'}
                    </span>
                  </div>

                  <p className="text-xs text-gray-600 leading-relaxed bg-gray-50 p-3.5 rounded-xl border border-gray-100">
                    {post.content}
                  </p>

                  {/* Replies already posted */}
                  {post.replies.length > 0 && (
                    <div className="space-y-3 pt-3 border-t border-gray-50">
                      <h5 className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Agronomist Diagnosis & Response</h5>
                      {post.replies.map((rep) => (
                        <div key={rep.id} className="rounded-xl border border-emerald-50 bg-emerald-50/20 p-3.5 space-y-1.5">
                          <p className="text-xs font-bold text-emerald-950 flex items-center space-x-1">
                            <ShieldCheck className="h-4 w-4 text-emerald-600" />
                            <span>{rep.authorName} (Expert Advisor)</span>
                          </p>
                          <p className="text-xs text-emerald-900 leading-relaxed font-medium">
                            {rep.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reply Action Toggle */}
                  <div className="flex justify-end pt-2">
                    {activeReplyPostId === post.id ? (
                      <div className="w-full space-y-3">
                        <textarea
                          placeholder="Type your biological diagnosis, chemical recommendations, and prevention advice here..."
                          rows={3}
                          value={replyContent}
                          onChange={(e) => setReplyContent(e.target.value)}
                          className="w-full rounded-xl border border-emerald-100 bg-white p-3.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          id={`expert-reply-textarea-${post.id}`}
                        />
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => {
                              setActiveReplyPostId(null);
                              setReplyContent('');
                            }}
                            className="rounded-lg px-4 py-1.5 text-xs font-semibold text-gray-500 hover:bg-gray-50"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleReplySubmit(post.id)}
                            disabled={isSubmittingReply || !replyContent.trim()}
                            className="rounded-lg bg-emerald-600 px-5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                            id={`expert-reply-submit-${post.id}`}
                          >
                            Post Response
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          setActiveReplyPostId(post.id);
                          setReplyContent('');
                        }}
                        className="rounded-xl bg-emerald-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-all shadow-sm"
                        id={`expert-reply-trigger-${post.id}`}
                      >
                        {post.replies.length > 0 ? 'Add Secondary Advice' : 'Diagnose & Reply'}
                      </button>
                    )}
                  </div>

                </div>
              ))
            )}
          </div>

        </div>
      )}

      {/* VIEW: PATHOLOGY CONTROL */}
      {expertSubTab === 'disease-db' && (
        <div className="space-y-6" id="expert-view-diseasedb">
          
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Crop Pathology Database</h2>
              <p className="text-xs text-gray-500">Add biological plant diseases, pathogen causes, prevention parameters, and recommended product mapping codes.</p>
            </div>
            <button
              onClick={() => setIsAddingDisease(!isAddingDisease)}
              className="flex items-center justify-center space-x-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-all"
              id="expert-add-disease-btn"
            >
              <Plus className="h-4 w-4" />
              <span>Add Pathology Profile</span>
            </button>
          </div>

          {/* Add Disease Form Drawer */}
          {isAddingDisease && (
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50/40 p-5 shadow-inner" id="add-disease-form-container">
              <h3 className="text-sm font-bold text-emerald-950 mb-4 flex items-center space-x-2">
                <Database className="h-4.5 w-4.5 text-emerald-600" />
                <span>Register a Plant Pathology Profile</span>
              </h3>
              
              <form onSubmit={handleDiseaseSubmit} className="space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Disease Common Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Downy Mildew"
                      value={disName}
                      onChange={(e) => setDisName(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Affected Crop Varieties (comma separated) *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Cucumber, Squash, Tomato"
                      value={disCrops}
                      onChange={(e) => setDisCrops(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-gray-700 mb-1">Biological Description / Pathogen Info *</label>
                    <textarea
                      required
                      rows={2}
                      placeholder="Scientific name of pathogen, weather promoters, spore spread details..."
                      value={disDesc}
                      onChange={(e) => setDisDesc(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Detailed Physical Symptoms *</label>
                    <textarea
                      required
                      rows={2}
                      placeholder="Visual indicators, leaf colors, growth curls, root rot stages..."
                      value={disSymptoms}
                      onChange={(e) => setDisSymptoms(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Pathogen Causes / Environmental Conditions</label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Phytophthora infestans promoted by high moisture and temperatures under 20C..."
                      value={disCauses}
                      onChange={(e) => setDisCauses(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-gray-700 mb-1">Prevention & Remediation Steps</label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Clear harvest waste, spray copper preventatively, rotate crop fields..."
                      value={disPrevention}
                      onChange={(e) => setDisPrevention(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Product mapping selection checkboxes */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-gray-700">Recommend Specific Catalog Remediation Products</label>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
                    {products.map((p) => (
                      <label 
                        key={p.id} 
                        className={`flex items-start space-x-2 rounded-xl border p-2.5 text-[10px] font-semibold cursor-pointer transition-all ${
                          disRecProducts.includes(p.id) 
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-950' 
                            : 'bg-white border-gray-100 text-gray-500 hover:bg-gray-50'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={disRecProducts.includes(p.id)}
                          onChange={() => handleProductToggle(p.id)}
                          className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                        />
                        <div className="flex flex-col">
                          <span className="line-clamp-1">{p.name}</span>
                          <span className="text-[8.5px] text-gray-400 capitalize">{p.category.toLowerCase()}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {diseaseError && (
                  <div className="flex items-center space-x-2 text-xs text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-100">
                    <AlertCircle className="h-4 w-4" />
                    <span>{diseaseError}</span>
                  </div>
                )}

                <div className="flex justify-end space-x-2 pt-2 border-t border-emerald-100/65">
                  <button
                    type="button"
                    onClick={() => setIsAddingDisease(false)}
                    className="rounded-lg px-4 py-1.5 text-xs font-semibold text-gray-500 hover:bg-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingDisease}
                    className="rounded-lg bg-emerald-600 px-5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                  >
                    {isSubmittingDisease ? 'Saving Pathology Record...' : 'Publish Pathology Profile'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Diseases catalogs render table */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2" id="expert-diseases-grid-list">
            {diseases.map((dis) => (
              <div 
                key={dis.id}
                className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                id={`disease-db-card-${dis.id}`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="text-base font-black text-gray-950">{dis.name}</h4>
                    <span className="text-[10px] font-bold text-gray-400">ID: {dis.id}</span>
                  </div>

                  <p className="text-xs text-gray-600 leading-relaxed mt-2">{dis.description}</p>

                  <div className="mt-4 space-y-2 border-t border-gray-50 pt-3">
                    <p className="text-xs text-gray-500 leading-relaxed">
                      <strong className="text-gray-700 font-bold">Affected Crops:</strong> {dis.affectedCrops.join(', ')}
                    </p>
                    <p className="text-xs text-gray-500 leading-relaxed">
                      <strong className="text-gray-700 font-bold">Visual Symptoms:</strong> {dis.symptoms}
                    </p>
                    <p className="text-xs text-gray-500 leading-relaxed">
                      <strong className="text-gray-700 font-bold">Causes:</strong> {dis.causes || 'Biological spores.'}
                    </p>
                    <p className="text-xs text-gray-500 leading-relaxed">
                      <strong className="text-gray-700 font-bold">Prevention & Care:</strong> {dis.prevention}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-gray-50 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg">
                    Mapped solutions: {dis.recommendedProductIds.length} Products
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

    </div>
  );
}
