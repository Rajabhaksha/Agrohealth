import React, { useState, useMemo } from 'react';
import { 
  MessageSquare, Plus, Check, ShieldCheck, HelpCircle, ArrowRight, User, 
  Search, Filter, Send, AlertCircle, Sparkles, BookOpen 
} from 'lucide-react';
import { ForumPost, ForumReply, User as UserType } from '../types';

interface ForumSectionProps {
  posts: ForumPost[];
  currentUser: UserType | null;
  onAddPost: (postData: Partial<ForumPost>) => Promise<void>;
  onPostReply: (postId: string, content: string) => Promise<void>;
  onOpenLogin: () => void;
}

export default function ForumSection({
  posts,
  currentUser,
  onAddPost,
  onPostReply,
  onOpenLogin,
}: ForumSectionProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCropFilter, setSelectedCropFilter] = useState<string | 'ALL'>('ALL');

  // New Post Form State
  const [isAsking, setIsAsking] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostCrop, setNewPostCrop] = useState('Tomato');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New Reply State
  const [activeReplyId, setActiveReplyId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);

  // Filter posts
  const filteredPosts = useMemo(() => {
    return posts.filter((post) => {
      const matchesSearch = 
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.content.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCrop = selectedCropFilter === 'ALL' || post.cropType === selectedCropFilter;

      return matchesSearch && matchesCrop;
    });
  }, [posts, searchTerm, selectedCropFilter]);

  // Extract unique crops for filter
  const uniqueCrops = useMemo(() => {
    const crops = new Set<string>();
    posts.forEach(p => {
      if (p.cropType) crops.add(p.cropType);
    });
    return Array.from(crops);
  }, [posts]);

  // Submit Post
  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenLogin();
      return;
    }
    if (!newPostTitle.trim() || !newPostContent.trim()) return;

    setIsSubmitting(true);
    try {
      await onAddPost({
        title: newPostTitle,
        content: newPostContent,
        cropType: newPostCrop
      });

      setNewPostTitle('');
      setNewPostContent('');
      setIsAsking(false);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Reply
  const handleReplySubmit = async (postId: string) => {
    if (!currentUser) {
      onOpenLogin();
      return;
    }
    if (!replyText.trim()) return;

    setIsSubmittingReply(true);
    try {
      await onPostReply(postId, replyText);
      setReplyText('');
      setActiveReplyId(null);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmittingReply(false);
    }
  };

  return (
    <div className="space-y-6" id="forum-section-container">
      
      {/* Upper info card */}
      <div className="rounded-3xl border border-emerald-100 bg-emerald-50/50 p-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-emerald-950 flex items-center space-x-2">
            <MessageSquare className="h-5 w-5 text-emerald-600" />
            <span>Community Crop Advisory Board</span>
          </h2>
          <p className="text-xs text-emerald-800 max-w-xl">
            Ask agricultural management questions, describe field anomalies, and read checked agronomist diagnoses.
          </p>
        </div>

        <button
          onClick={() => currentUser ? setIsAsking(!isAsking) : onOpenLogin()}
          className="rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center justify-center space-x-1.5"
          id="forum-ask-question-btn"
        >
          <Plus className="h-4 w-4" />
          <span>Post Discussion Topic</span>
        </button>
      </div>

      {/* Filter and Search controls */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search discussion topics or keywords..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-gray-200 bg-white py-2 pl-10 pr-4 text-xs text-gray-900 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 transition-all shadow-sm"
          />
        </div>

        {/* Crop Filter Dropdown */}
        <div className="flex items-center space-x-1.5 rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-xs shadow-sm">
          <Filter className="h-3.5 w-3.5 text-gray-400" />
          <span className="font-semibold text-gray-500 mr-1">Crop Variety:</span>
          <select
            value={selectedCropFilter}
            onChange={(e) => setSelectedCropFilter(e.target.value)}
            className="bg-transparent font-semibold text-emerald-700 focus:outline-none"
            id="forum-crop-filter"
          >
            <option value="ALL">All Crops</option>
            {uniqueCrops.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Ask Question Form Section */}
      {isAsking && (
        <div className="rounded-2xl border border-emerald-100 bg-white p-5 shadow-md space-y-4 animate-fadeIn" id="forum-ask-form-container">
          <h3 className="text-sm font-bold text-emerald-950 flex items-center space-x-2">
            <HelpCircle className="h-4.5 w-4.5 text-emerald-600" />
            <span>Open a Discussion Thread</span>
          </h3>

          <form onSubmit={handlePostSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-gray-700 mb-1">Topic Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tomato foliage has yellow lesions, is this powdery mildew?"
                  value={newPostTitle}
                  onChange={(e) => setNewPostTitle(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs text-gray-900 focus:border-emerald-500 focus:outline-none"
                  id="forum-new-title"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Crop Category</label>
                <select
                  value={newPostCrop}
                  onChange={(e) => setNewPostCrop(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs text-gray-900 focus:border-emerald-500 focus:outline-none"
                  id="forum-new-crop"
                >
                  <option value="Tomato">Tomato</option>
                  <option value="Potato">Potato</option>
                  <option value="Cucumber">Cucumber</option>
                  <option value="Squash">Squash</option>
                  <option value="Wheat">Wheat</option>
                  <option value="Maize">Maize / Corn</option>
                  <option value="General">Other / General</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Details & Crop History *</label>
              <textarea
                required
                rows={3}
                placeholder="Give background details: what pesticides have you tried? What season are you currently growing? How long have the spots been visible?"
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                className="w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs text-gray-900 focus:border-emerald-500 focus:outline-none"
                id="forum-new-content"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2 border-t border-gray-50">
              <button
                type="button"
                onClick={() => setIsAsking(false)}
                className="rounded-lg px-4 py-1.5 text-xs font-semibold text-gray-500 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="rounded-lg bg-emerald-600 px-5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                id="forum-new-submit"
              >
                {isSubmitting ? 'Posting Thread...' : 'Publish Topic'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Topics list */}
      <div className="space-y-4" id="forum-topics-list">
        {filteredPosts.length === 0 ? (
          <div className="text-center py-12 border border-gray-100 rounded-3xl bg-white">
            <MessageSquare className="mx-auto h-12 w-12 text-gray-300" />
            <h3 className="mt-4 text-sm font-bold text-gray-900">No discussions match your filter</h3>
            <p className="mt-2 text-xs text-gray-500">Try checking your spelling or clearing search and crop category filters.</p>
          </div>
        ) : (
          filteredPosts.map((post) => (
            <div 
              key={post.id}
              className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm space-y-4"
              id={`forum-topic-${post.id}`}
            >
              {/* Header row */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100">
                      Crop: {post.cropType || 'General'}
                    </span>
                    <span className="text-[10px] text-gray-400 font-semibold flex items-center space-x-1">
                      <User className="h-3 w-3" />
                      <span>Posted by {post.authorName} ({post.authorRole.toLowerCase()})</span>
                    </span>
                  </div>
                  <h4 className="text-sm font-extrabold text-gray-950 mt-1.5">{post.title}</h4>
                </div>
              </div>

              <p className="text-xs text-gray-600 leading-relaxed">
                {post.content}
              </p>

              {/* Replies */}
              {post.replies.length > 0 && (
                <div className="space-y-3 pt-3 border-t border-gray-50">
                  <h5 className="text-[10px] font-bold uppercase tracking-wider text-gray-400">Discussion Responses</h5>
                  {post.replies.map((rep) => (
                    <div key={rep.id} className="rounded-xl bg-gray-50 p-3.5 space-y-1">
                      <p className="text-[10.5px] font-bold text-gray-900 flex items-center space-x-1">
                        {rep.authorRole === 'EXPERT' ? (
                          <>
                            <ShieldCheck className="h-4 w-4 text-emerald-600" />
                            <span className="text-emerald-800">{rep.authorName} (Verified Expert)</span>
                          </>
                        ) : (
                          <>
                            <User className="h-3 w-3 text-gray-400" />
                            <span>{rep.authorName} (Farmer)</span>
                          </>
                        )}
                      </p>
                      <p className="text-xs text-gray-700 leading-relaxed font-medium">
                        {rep.content}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* Add Comment Reply action */}
              <div className="flex justify-end pt-2">
                {activeReplyId === post.id ? (
                  <div className="w-full space-y-2">
                    <textarea
                      placeholder="Post helpful tips, treatment suggestions, or ask further questions..."
                      rows={2}
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 bg-white p-3 text-xs text-gray-950 focus:border-emerald-500 focus:outline-none"
                    />
                    <div className="flex justify-end space-x-1.5">
                      <button
                        onClick={() => {
                          setActiveReplyId(null);
                          setReplyText('');
                        }}
                        className="rounded-lg px-3 py-1.5 text-xs font-semibold text-gray-500 hover:bg-gray-100"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleReplySubmit(post.id)}
                        disabled={isSubmittingReply || !replyText.trim()}
                        className="rounded-lg bg-emerald-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                        id={`forum-reply-submit-${post.id}`}
                      >
                        Send Reply
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      if (!currentUser) {
                        onOpenLogin();
                        return;
                      }
                      setActiveReplyId(post.id);
                      setReplyText('');
                    }}
                    className="inline-flex items-center space-x-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-950"
                    id={`forum-reply-trigger-${post.id}`}
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>Post Reply</span>
                  </button>
                )}
              </div>

            </div>
          ))
        )}
      </div>

    </div>
  );
}
