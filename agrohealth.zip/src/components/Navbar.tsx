import { Sprout, ShoppingBag, User, LogOut, ArrowRight, ShieldCheck, HelpCircle, X, Sparkles, Database } from 'lucide-react';
import { User as UserType, UserRole } from '../types';

interface NavbarProps {
  currentUser: UserType | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onRoleSwitch: (role: UserRole) => void;
  cartCount: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  onLogout: () => void;
  onOpenLogin: () => void;
}

export default function Navbar({
  currentUser,
  activeTab,
  setActiveTab,
  onRoleSwitch,
  cartCount,
  isCartOpen,
  setIsCartOpen,
  onLogout,
  onOpenLogin,
}: NavbarProps) {
  // Navigation links based on role
  const getNavLinks = () => {
    if (!currentUser) {
      return [
        { id: 'marketplace', label: 'Marketplace' },
        { id: 'diseases', label: 'Disease Catalog' },
        { id: 'forum', label: 'Farmer Forum' },
      ];
    }

    if (currentUser.role === 'FARMER') {
      return [
        { id: 'farmer-dashboard', label: 'My Farm' },
        { id: 'diagnosis', label: 'AI Diagnostic' },
        { id: 'marketplace', label: 'Marketplace' },
        { id: 'diseases', label: 'Disease Catalog' },
        { id: 'forum', label: 'Q&A Forum' },
      ];
    }

    if (currentUser.role === 'EXPERT') {
      return [
        { id: 'expert-dashboard', label: 'Expert Panel' },
        { id: 'diseases', label: 'Manage Diseases' },
        { id: 'forum', label: 'Consultations' },
      ];
    }

    if (currentUser.role === 'ADMIN') {
      return [
        { id: 'admin-dashboard', label: 'Admin Panel' },
        { id: 'marketplace', label: 'Manage Products' },
        { id: 'diseases', label: 'Disease Database' },
        { id: 'forum', label: 'Community Forum' },
      ];
    }

    return [];
  };

  const navLinks = getNavLinks();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-emerald-100 bg-white/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Left: Brand logo */}
        <div 
          className="flex cursor-pointer items-center space-x-2 text-emerald-700 hover:opacity-90"
          onClick={() => setActiveTab(currentUser ? (currentUser.role === 'FARMER' ? 'farmer-dashboard' : currentUser.role === 'EXPERT' ? 'expert-dashboard' : 'admin-dashboard') : 'marketplace')}
          id="navbar-brand-logo"
        >
          <div className="rounded-xl bg-emerald-600 p-2 text-white shadow-md shadow-emerald-200">
            <Sprout className="h-6 w-6" />
          </div>
          <span className="text-xl font-bold tracking-tight text-emerald-950">Agro<span className="text-emerald-600">Health</span></span>
        </div>

        {/* Center: Main Nav Links */}
        <nav className="hidden md:flex space-x-1" id="navbar-main-nav">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => setActiveTab(link.id)}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                activeTab === link.id
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
              id={`nav-link-${link.id}`}
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Right: Cart, Profile & Role Quick Switcher */}
        <div className="flex items-center space-x-4">
          
          {/* Quick Swapper (for demo/evaluator convenience) */}
          <div className="hidden sm:flex items-center space-x-1 rounded-xl bg-gray-100 p-1 text-xs font-semibold text-gray-500 border border-gray-200">
            <span className="px-2 text-[10px] uppercase tracking-wider text-gray-400">View As:</span>
            <button
              onClick={() => onRoleSwitch('FARMER')}
              className={`rounded-lg px-2 py-1 transition-all ${
                currentUser?.role === 'FARMER'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'hover:text-gray-900'
              }`}
              id="navbar-switch-farmer"
            >
              Farmer
            </button>
            <button
              onClick={() => onRoleSwitch('EXPERT')}
              className={`rounded-lg px-2 py-1 transition-all ${
                currentUser?.role === 'EXPERT'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'hover:text-gray-900'
              }`}
              id="navbar-switch-expert"
            >
              Expert
            </button>
            <button
              onClick={() => onRoleSwitch('ADMIN')}
              className={`rounded-lg px-2 py-1 transition-all ${
                currentUser?.role === 'ADMIN'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'hover:text-gray-900'
              }`}
              id="navbar-switch-admin"
            >
              Admin
            </button>
          </div>

          {/* Cart Icon (Shown mostly to Farmers or Guests) */}
          {(!currentUser || currentUser.role === 'FARMER') && (
            <button
              onClick={() => setIsCartOpen(!isCartOpen)}
              className="relative rounded-xl border border-gray-200 bg-white p-2 text-gray-600 hover:bg-gray-50 hover:text-emerald-600 transition-all shadow-sm"
              aria-label="Shopping Cart"
              id="navbar-cart-btn"
            >
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-600 text-[10px] font-bold text-white ring-2 ring-white animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>
          )}

          {/* User Info / Profile Button */}
          {currentUser ? (
            <div className="flex items-center space-x-3 border-l border-gray-100 pl-4">
              <div className="hidden lg:block text-right">
                <p className="text-sm font-semibold text-gray-900">{currentUser.name}</p>
                <div className="flex items-center justify-end space-x-1">
                  {currentUser.role === 'FARMER' && (
                    <span className="inline-flex items-center rounded-full bg-emerald-100 px-1.5 py-0.5 text-[10px] font-medium text-emerald-800">
                      Farmer
                    </span>
                  )}
                  {currentUser.role === 'EXPERT' && (
                    <span className="inline-flex items-center rounded-full bg-teal-100 px-1.5 py-0.5 text-[10px] font-medium text-teal-800">
                      Expert Advisor
                    </span>
                  )}
                  {currentUser.role === 'ADMIN' && (
                    <span className="inline-flex items-center rounded-full bg-purple-100 px-1.5 py-0.5 text-[10px] font-medium text-purple-800">
                      System Admin
                    </span>
                  )}
                </div>
              </div>
              <button
                onClick={onLogout}
                className="rounded-xl border border-red-100 bg-red-50 p-2 text-red-600 hover:bg-red-100 transition-all"
                title="Logout"
                id="navbar-logout-btn"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenLogin}
              className="flex items-center space-x-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-emerald-200 hover:bg-emerald-700 hover:shadow-lg transition-all"
              id="navbar-login-btn"
            >
              <User className="h-4 w-4" />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile view sub-navbar role switcher */}
      <div className="flex sm:hidden border-t border-gray-100 justify-around bg-gray-50 py-1.5 px-4 text-xs">
        <button
          onClick={() => onRoleSwitch('FARMER')}
          className={`px-3 py-1 rounded-md ${currentUser?.role === 'FARMER' ? 'bg-emerald-600 text-white font-bold' : 'text-gray-500'}`}
        >
          Farmer
        </button>
        <button
          onClick={() => onRoleSwitch('EXPERT')}
          className={`px-3 py-1 rounded-md ${currentUser?.role === 'EXPERT' ? 'bg-teal-600 text-white font-bold' : 'text-gray-500'}`}
        >
          Expert
        </button>
        <button
          onClick={() => onRoleSwitch('ADMIN')}
          className={`px-3 py-1 rounded-md ${currentUser?.role === 'ADMIN' ? 'bg-purple-600 text-white font-bold' : 'text-gray-500'}`}
        >
          Admin
        </button>
      </div>
    </header>
  );
}
